// lib/features/time_entry/controller/time_entry_controller.dart

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../data/time_entry_model.dart';
import '../data/time_entry_repository.dart';
import '../../../services/google_travel_service.dart';

final timeEntryControllerProvider =
    StateNotifierProvider<TimeEntryController, TimeEntryState>((ref) {
  final repo = TimeEntryRepository(Supabase.instance.client);
  final google = GoogleTravelService(Supabase.instance.client);
  return TimeEntryController(repo, google);
});

// ------------------------------------------------------------
// STATE
// ------------------------------------------------------------
class TimeEntryState {
  final bool loading;
  final String? error;
  final String? successMessage;

  // Fields populated by UI
  final String? selectedEmployeeId;
  final String? selectedProjectId;
  final String? selectedPlantId;

  final DateTime date;
  final DateTime startTime;
  final DateTime finishTime;

  final List<TimeBreak> breaks;

  final bool onCall;
  final int travelToSiteMin;
  final int travelFromSiteMin;
  final int miscAllowanceMin;
  final String comments;
  final int? concreteTicket;
  final String? concreteMixType;
  final double? concreteQty;

  final bool plantMode;
  final double? distanceKm;

  final List<String> usedPlantIds;
  final List<String> mobilisedPlantIds;

  TimeEntryState({
    this.loading = false,
    this.error,
    this.successMessage,
    this.selectedEmployeeId,
    this.selectedProjectId,
    this.selectedPlantId,
    DateTime? date,
    DateTime? startTime,
    DateTime? finishTime,
    this.breaks = const [],
    this.onCall = false,
    this.travelToSiteMin = 0,
    this.travelFromSiteMin = 0,
    this.miscAllowanceMin = 0,
    this.comments = "",
    this.concreteTicket,
    this.concreteMixType,
    this.concreteQty,
    this.plantMode = false,
    this.distanceKm,
    this.usedPlantIds = const [],
    this.mobilisedPlantIds = const [],
  })  : date = date ?? DateTime.now(),
        startTime = startTime ?? DateTime.now(),
        finishTime = finishTime ?? DateTime.now();

  TimeEntryState copyWith({
    bool? loading,
    String? error,
    String? successMessage,
    String? selectedEmployeeId,
    String? selectedProjectId,
    String? selectedPlantId,
    DateTime? date,
    DateTime? startTime,
    DateTime? finishTime,
    List<TimeBreak>? breaks,
    bool? onCall,
    int? travelToSiteMin,
    int? travelFromSiteMin,
    int? miscAllowanceMin,
    String? comments,
    int? concreteTicket,
    String? concreteMixType,
    double? concreteQty,
    bool? plantMode,
    double? distanceKm,
    List<String>? usedPlantIds,
    List<String>? mobilisedPlantIds,
  }) {
    return TimeEntryState(
      loading: loading ?? this.loading,
      error: error,
      successMessage: successMessage,
      selectedEmployeeId: selectedEmployeeId ?? this.selectedEmployeeId,
      selectedProjectId: selectedProjectId ?? this.selectedProjectId,
      selectedPlantId: selectedPlantId ?? this.selectedPlantId,
      date: date ?? this.date,
      startTime: startTime ?? this.startTime,
      finishTime: finishTime ?? this.finishTime,
      breaks: breaks ?? this.breaks,
      onCall: onCall ?? this.onCall,
      travelToSiteMin: travelToSiteMin ?? this.travelToSiteMin,
      travelFromSiteMin: travelFromSiteMin ?? this.travelFromSiteMin,
      miscAllowanceMin: miscAllowanceMin ?? this.miscAllowanceMin,
      comments: comments ?? this.comments,
      concreteTicket: concreteTicket ?? this.concreteTicket,
      concreteMixType: concreteMixType ?? this.concreteMixType,
      concreteQty: concreteQty ?? this.concreteQty,
      plantMode: plantMode ?? this.plantMode,
      distanceKm: distanceKm ?? this.distanceKm,
      usedPlantIds: usedPlantIds ?? this.usedPlantIds,
      mobilisedPlantIds: mobilisedPlantIds ?? this.mobilisedPlantIds,
    );
  }
}

// ------------------------------------------------------------
// CONTROLLER
// ------------------------------------------------------------
class TimeEntryController extends StateNotifier<TimeEntryState> {
  final TimeEntryRepository repo;
  final GoogleTravelService google;

  TimeEntryController(this.repo, this.google)
      : super(TimeEntryState());

  // ---------------------------
  // Mutators
  // ---------------------------
  void setEmployee(String id) =>
      state = state.copyWith(selectedEmployeeId: id);

  void setProject(String id) =>
      state = state.copyWith(selectedProjectId: id, plantMode: false);

  void setPlant(String id) =>
      state = state.copyWith(selectedPlantId: id, plantMode: true);

  void setDate(DateTime date) =>
      state = state.copyWith(date: date);

  void setStartTime(DateTime t) =>
      state = state.copyWith(startTime: t);

  void setFinishTime(DateTime t) =>
      state = state.copyWith(finishTime: t);

  void addBreak() {
    if (state.breaks.length >= 3) return;
    final updated = [...state.breaks, TimeBreak.empty()];
    state = state.copyWith(breaks: updated);
  }

  void updateBreak(int index, TimeBreak b) {
    final updated = [...state.breaks];
    updated[index] = b;
    state = state.copyWith(breaks: updated);
  }

  void removeBreak(int index) {
    final updated = [...state.breaks]..removeAt(index);
    state = state.copyWith(breaks: updated);
  }

  void setOnCall(bool val) =>
      state = state.copyWith(onCall: val);

  void setTravelTo(int m) =>
      state = state.copyWith(travelToSiteMin: m);

  void setTravelFrom(int m) =>
      state = state.copyWith(travelFromSiteMin: m);

  void setMisc(int m) =>
      state = state.copyWith(miscAllowanceMin: m);

  void setComments(String text) =>
      state = state.copyWith(comments: text);

  void setConcreteTicket(int? ticket) =>
      state = state.copyWith(concreteTicket: ticket);

  void setConcreteMix(String? mix) =>
      state = state.copyWith(concreteMixType: mix);

  void setConcreteQty(double? qty) =>
      state = state.copyWith(concreteQty: qty);

  void setUsedPlant(List<String> plantIds) =>
      state = state.copyWith(usedPlantIds: plantIds);

  void setMobilisedPlant(List<String> plantIds) =>
      state = state.copyWith(mobilisedPlantIds: plantIds);

  // ---------------------------
  // Compute total break minutes
  // ---------------------------
  int _calculateBreakMinutes() {
    int total = 0;
    for (final b in state.breaks) {
      if (b.start != null && b.end != null) {
        final diff = b.end!.difference(b.start!).inMinutes;
        if (diff > 0) total += diff;
      }
    }
    return total;
  }

  // ---------------------------
  // Google distance lookup
  // ---------------------------
  Future<void> calculateDistance({
    required double homeLat,
    required double homeLng,
    required double projLat,
    required double projLng,
    required String displayName,
  }) async {
    try {
      final result = await google.getDistanceAndTime(
        homeLat: homeLat,
        homeLng: homeLng,
        projectLat: projLat,
        projectLng: projLng,
        userDisplayName: displayName,
      );

      state = state.copyWith(distanceKm: result.distanceKm);

    } catch (e) {
      state = state.copyWith(error: "Failed to calculate travel details");
    }
  }

  // ---------------------------
  // SAVE ENTRY
  // ---------------------------
  Future<void> saveEntry() async {
    // Validation  
    if (state.selectedEmployeeId == null) {
      state = state.copyWith(error: "No employee selected");
      return;
    }

    if (!state.plantMode && state.selectedProjectId == null) {
      state = state.copyWith(error: "No project selected");
      return;
    }

    if (state.plantMode && state.selectedPlantId == null) {
      state = state.copyWith(error: "No plant selected");
      return;
    }

    state = state.copyWith(loading: true, error: null, successMessage: null);

    try {
      // Convert times
      final start = state.startTime;
      final finish = state.finishTime;
      final breaks = _calculateBreakMinutes();

      // Build model
      final entry = TimeEntryModel(
        userId: state.selectedEmployeeId!,
        projectId: state.plantMode ? null : state.selectedProjectId,
        mechanicPlantId: state.plantMode ? state.selectedPlantId : null,
        date: state.date,
        start: start,
        finish: finish,
        travelToSiteMin: state.travelToSiteMin,
        travelFromSiteMin: state.travelFromSiteMin,
        miscAllowanceMin: state.miscAllowanceMin,
        onCall: state.onCall,
        comments: state.comments,
        concreteTicket: state.concreteTicket,
        concreteMixType: state.concreteMixType,
        concreteQty: state.concreteQty,
        distanceKm: state.distanceKm,
        synced: true, // If offline logic added later → change here
        offlineCreated: false,
      );

      // Save everything
      await repo.saveCompleteEntry(
        entry: entry,
        breaks: state.breaks,
        usedPlantIds: state.usedPlantIds,
        mobilisedPlantIds: state.mobilisedPlantIds,
      );

      state = state.copyWith(
          loading: false, successMessage: "Time entry saved successfully");

    } catch (e) {
      state = state.copyWith(
          loading: false, error: e.toString());
    }
  }
}
