import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../controller/time_entry_controller.dart';

class PlantSection extends ConsumerWidget {
  final String? selectedPlantId;
  final void Function(String?) onChanged;
  final TimeEntryController controller;

  const PlantSection({
    super.key,
    required this.selectedPlantId,
    required this.onChanged,
    required this.controller,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final plantList = ref.watch(plantListProvider);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black12,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // HEADER
          Row(
            children: const [
              Icon(Icons.agriculture, size: 22),
              SizedBox(width: 8),
              Text(
                "Plant Equipment",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // PLANT DROPDOWN
          plantList.when(
            data: (list) {
              return DropdownButtonFormField<String>(
                decoration: const InputDecoration(
                  labelText: "Select Plant Unit",
                  border: OutlineInputBorder(),
                ),
                value: selectedPlantId,
                items: list
                    .map(
                      (p) => DropdownMenuItem<String>(
                        value: p.id,
                        child: Text("${p.plantNo} — ${p.description}"),
                      ),
                    )
                    .toList(),
                onChanged: onChanged,
              );
            },
            loading: () => const LinearProgressIndicator(),
            error: (_, __) => const Text("Failed to load plant list"),
          ),

          const SizedBox(height: 12),

          ElevatedButton.icon(
            onPressed: () async {
              final last = await controller.findLastPlantWorkedOn();
              if (last != null) {
                onChanged(last.id);

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Last worked plant: ${last.plantNo}")),
                );
              }
            },
            icon: const Icon(Icons.history),
            label: const Text("Use Last Plant Worked On"),
          ),
        ],
      ),
    );
  }
}
