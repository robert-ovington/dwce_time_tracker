import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../providers/user_data_provider.dart';
import '../../../providers/large_plant_provider.dart';
import '../../../providers/time_entry_controller.dart';

class FleetSection extends ConsumerWidget {
  const FleetSection({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userData = ref.watch(currentUserDataProvider).value;

    // If the user's profile says fleet options should not be shown → hide
    if (userData == null || userData.showFleet == false) {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: const [
            Icon(Icons.agriculture, color: Colors.white),
            SizedBox(width: 8),
            Text(
              "Fleet (Large Plant)",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),

        const SizedBox(height: 16),

        _buildRecallButtons(context, ref),

        const SizedBox(height: 16),

        _buildUsedPlantCard(context, ref),

        const SizedBox(height: 12),

        _buildMobilisedPlantCard(context, ref),
      ],
    );
  }

  // ------------------------------------------------------------
  // BUTTONS: Recall + Save Fleet
  // ------------------------------------------------------------
  Widget _buildRecallButtons(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(timeEntryControllerProvider);

    return Row(
      children: [
        ElevatedButton.icon(
          onPressed: controller.isRecallingFleet
              ? null
              : () {
                  ref
                      .read(timeEntryControllerProvider.notifier)
                      .recallSavedFleet();
                },
          icon: const Icon(Icons.refresh),
          label: Text(
            controller.isRecallingFleet ? "Loading…" : "Recall Saved Fleet",
          ),
        ),
        const SizedBox(width: 12),
        TextButton.icon(
          onPressed: controller.isSavingFleet
              ? null
              : () {
                  ref
                      .read(timeEntryControllerProvider.notifier)
                      .saveCurrentFleet();
                },
          icon: const Icon(Icons.save),
          label: Text(
            controller.isSavingFleet ? "Saving…" : "Save as My Fleet",
          ),
        ),
      ],
    );
  }

  // ------------------------------------------------------------
  // USED PLANT (Check the plant used today)
  // ------------------------------------------------------------
  Widget _buildUsedPlantCard(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(timeEntryControllerProvider);
    final plantsAsync = ref.watch(activeLargePlantProvider);

    return Card(
      color: Colors.blueGrey.shade900,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: plantsAsync.when(
          data: (plants) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Plant Used Today",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                const SizedBox(height: 10),

                for (var plant in plants)
                  CheckboxListTile(
                    value: controller.usedPlantIds.contains(plant.id),
                    title: Text("${plant.plantNo} — ${plant.shortDescription}"),
                    onChanged: (value) {
                      ref
                          .read(timeEntryControllerProvider.notifier)
                          .toggleUsedPlant(plant.id, value ?? false);
                    },
                  ),
              ],
            );
          },
          loading: () =>
              const Padding(padding: EdgeInsets.all(8), child: CircularProgressIndicator()),
          error: (err, _) => Text("Error: $err"),
        ),
      ),
    );
  }

  // ------------------------------------------------------------
  // MOBILISED PLANT
  // ------------------------------------------------------------
  Widget _buildMobilisedPlantCard(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(timeEntryControllerProvider);
    final plantsAsync = ref.watch(activeLargePlantProvider);

    return Card(
      color: Colors.blueGrey.shade900,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: plantsAsync.when(
          data: (plants) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Plant Mobilised (sent to another project)",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                const SizedBox(height: 10),

                for (var plant in plants)
                  CheckboxListTile(
                    value: controller.mobilisedPlantIds.contains(plant.id),
                    title: Text("${plant.plantNo} — ${plant.shortDescription}"),
                    onChanged: (value) {
                      ref
                          .read(timeEntryControllerProvider.notifier)
                          .toggleMobilisedPlant(plant.id, value ?? false);
                    },
                  ),
              ],
            );
          },
          loading: () =>
              const Padding(padding: EdgeInsets.all(8), child: CircularProgressIndicator()),
          error: (err, _) => Text("Error: $err"),
        ),
      ),
    );
  }
}
