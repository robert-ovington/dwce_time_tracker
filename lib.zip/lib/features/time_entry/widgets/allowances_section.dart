import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../providers/user_data_provider.dart';
import '../../../providers/concrete_mix_provider.dart';
import '../../controller/time_entry_controller.dart';

class AllowancesSection extends ConsumerWidget {
  final TimeEntryController controller;

  final int travelTo;
  final int travelFrom;
  final int miscMinutes;
  final bool onCall;

  final void Function(int) onTravelToChanged;
  final void Function(int) onTravelFromChanged;
  final void Function(int) onMiscChanged;
  final void Function(bool) onOnCallChanged;

  final Function(int?) onConcreteTicketChanged;
  final Function(String?) onConcreteTypeChanged;
  final Function(String?) onConcreteQtyChanged;

  final int? concreteTicketNo;
  final String? concreteMixType;
  final String? concreteQty;

  const AllowancesSection({
    super.key,
    required this.controller,
    required this.travelTo,
    required this.travelFrom,
    required this.miscMinutes,
    required this.onCall,
    required this.onTravelToChanged,
    required this.onTravelFromChanged,
    required this.onMiscChanged,
    required this.onOnCallChanged,
    required this.onConcreteTicketChanged,
    required this.onConcreteTypeChanged,
    required this.onConcreteQtyChanged,
    required this.concreteTicketNo,
    required this.concreteMixType,
    required this.concreteQty,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userData = ref.watch(userDataProvider);
    final mixList = ref.watch(concreteMixProvider);

    final isConcreteDriver = userData?.concreteMixLorry == true;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black12,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // HEADER
          Row(
            children: const [
              Icon(Icons.payments, size: 22),
              SizedBox(width: 8),
              Text(
                "Allowances",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // TRAVEL TIME ROW
          Row(
            children: [
              Expanded(child: _travelTile(
                label: "Travel To (min)",
                value: travelTo,
                onChanged: onTravelToChanged,
              )),
              const SizedBox(width: 12),
              Expanded(child: _travelTile(
                label: "Travel From (min)",
                value: travelFrom,
                onChanged: onTravelFromChanged,
              )),
            ],
          ),

          const SizedBox(height: 16),

          // AUTO-CALCULATE TRAVEL TIME BUTTON
          ElevatedButton.icon(
            onPressed: () async {
              final result = await controller.calculateTravelTime();

              if (result == null) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Unable to calculate travel time."),
                  ),
                );
                return;
              }

              onTravelToChanged(result.travelToMinutes);
              onTravelFromChanged(result.travelFromMinutes);

              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                    content: Text(
                        "Travel time updated — ${result.distanceKm.toStringAsFixed(1)} km")),
              );
            },
            icon: const Icon(Icons.route),
            label: const Text("Auto-Calculate Travel Time"),
          ),

          const SizedBox(height: 18),

          // ON-CALL + MISC
          Row(
            children: [
              Expanded(
                child: SwitchListTile(
                  title: const Text("On-Call"),
                  value: onCall,
                  onChanged: onOnCallChanged,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _miscTile(
                  label: "Misc Allowance (min)",
                  value: miscMinutes,
                  onChanged: onMiscChanged,
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          // ===============================
          // CONCRETE MIX TICKET SECTION
          // Only visible for concrete mix drivers
          // ===============================

          if (isConcreteDriver) ...[
            const Divider(height: 32),

            Row(
              children: const [
                Icon(Icons.local_shipping),
                SizedBox(width: 8),
                Text(
                  "Concrete Delivery",
                  style: TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // TICKET NUMBER
            TextFormField(
              initialValue:
                  concreteTicketNo?.toString() ?? "",
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Concrete Ticket No",
                border: OutlineInputBorder(),
              ),
              onChanged: (v) {
                final parsed = int.tryParse(v);
                onConcreteTicketChanged(parsed);
              },
            ),

            const SizedBox(height: 16),

            // MIX TYPE DROPDOWN
            mixList.when(
              data: (list) => DropdownButtonFormField<String>(
                value: concreteMixType,
                decoration: const InputDecoration(
                  labelText: "Concrete Mix Type",
                  border: OutlineInputBorder(),
                ),
                items: list
                    .map((m) => DropdownMenuItem<String>(
                          value: m.productNo,
                          child: Text(m.userDescription ?? m.productNo),
                        ))
                    .toList(),
                onChanged: onConcreteTypeChanged,
              ),
              loading: () => const LinearProgressIndicator(),
              error: (_, __) =>
                  const Text("Unable to load mix types"),
            ),

            const SizedBox(height: 16),

            // QUANTITY
            TextFormField(
              initialValue: concreteQty ?? "",
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Quantity (m³)",
                border: OutlineInputBorder(),
              ),
              onChanged: onConcreteQtyChanged,
            ),
          ]
        ],
      ),
    );
  }

  // -----------------------
  // PRIVATE SMALL WIDGETS
  // -----------------------

  Widget _travelTile({
    required String label,
    required int value,
    required void Function(int) onChanged,
  }) {
    return TextFormField(
      initialValue: value.toString(),
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      onChanged: (v) => onChanged(int.tryParse(v) ?? 0),
    );
  }

  Widget _miscTile({
    required String label,
    required int value,
    required void Function(int) onChanged,
  }) {
    return TextFormField(
      initialValue: value.toString(),
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      onChanged: (v) => onChanged(int.tryParse(v) ?? 0),
    );
  }
}
