import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../providers/user_data_provider.dart';
import '../../../providers/time_entry_controller.dart';
import '../../../providers/project_provider.dart';
import '../../../providers/large_plant_provider.dart';

class ProjectSection extends ConsumerWidget {
  const ProjectSection({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(timeEntryControllerProvider);
    final userData = ref.watch(currentUserDataProvider).value;

    final canUsePlantMode = userData != null &&
        userData.security != null &&
        userData.security >= 1 &&
        userData.security <= 6; // 1–6 allowed

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // SECTION LABEL
        Row(
          children: const [
            Icon(Icons.work_outline, color: Colors.white),
            SizedBox(width: 8),
            Text(
              "Work Location",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),

        const SizedBox(height: 16),

        // PROJECT / PLANT TOGGLE
        if (canUsePlantMode) _buildPlantToggle(context, ref, controller),

        const SizedBox(height: 16),

        // PROJECT OR PLANT DROPDOWN
        controller.plantMode
            ? _buildPlantDropdown(context, ref, controller)
            : _buildProjectDropdown(context, ref, controller),

        const SizedBox(height: 16),

        // FIND NEAREST JOB BUTTON (Projects Only)
        if (!controller.plantMode)
          _buildFindNearestJob(context, ref, controller),

        // FIND LAST JOB
        const SizedBox(height: 12),
        _buildFindLastJob(context, ref, controller),

        const SizedBox(height: 16),

        // PROJECT OR PLANT DETAILS CARD
        if (!controller.plantMode && controller.selectedProject != null)
          _buildProjectDetails(context, ref, controller),

        if (controller.plantMode && controller.selectedPlant != null)
          _buildPlantDetails(context, ref, controller),
      ],
    );
  }

  // ------------------------------------------------------------
  // PLANT MODE TOGGLE
  // ------------------------------------------------------------
  Widget _buildPlantToggle(BuildContext context, WidgetRef ref, TimeEntryController controller) {
    return CheckboxListTile(
      title: const Text(
        "Work on Plant instead of Project",
        style: TextStyle(fontSize: 16),
      ),
      value: controller.plantMode,
      onChanged: (value) {
        ref.read(timeEntryControllerProvider.notifier)
            .setPlantMode(value ?? false);
      },
    );
  }

  // ------------------------------------------------------------
  // PROJECT DROPDOWN
  // ------------------------------------------------------------
  Widget _buildProjectDropdown(BuildContext context, WidgetRef ref, TimeEntryController controller) {
    final projectsAsync = ref.watch(activeProjectsProvider);

    return projectsAsync.when(
      data: (projects) {
        return DropdownButtonFormField(
          value: controller.selectedProject,
          items: projects.map((proj) {
            return DropdownMenuItem(
              value: proj,
              child: Text(proj.projectName),
            );
          }).toList(),
          decoration: const InputDecoration(labelText: "Select Project"),
          onChanged: (value) {
            ref.read(timeEntryControllerProvider.notifier)
                .setSelectedProject(value);
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (err, _) => Text("Error loading projects: $err"),
    );
  }

  // ------------------------------------------------------------
  // PLANT DROPDOWN
  // ------------------------------------------------------------
  Widget _buildPlantDropdown(BuildContext context, WidgetRef ref, TimeEntryController controller) {
    final plantAsync = ref.watch(activeLargePlantProvider);

    return plantAsync.when(
      data: (plants) {
        return DropdownButtonFormField(
          value: controller.selectedPlant,
          items: plants.map((p) {
            return DropdownMenuItem(
              value: p,
              child: Text("${p.plantNo} — ${p.shortDescription}"),
            );
          }).toList(),
          decoration: const InputDecoration(labelText: "Select Plant"),
          onChanged: (value) {
            ref.read(timeEntryControllerProvider.notifier)
                .setSelectedPlant(value);
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (err, _) => Text("Error loading plant list: $err"),
    );
  }

  // ------------------------------------------------------------
  // FIND NEAREST JOB
  // ------------------------------------------------------------
  Widget _buildFindNearestJob(BuildContext context, WidgetRef ref, TimeEntryController controller) {
    return ElevatedButton.icon(
      onPressed: controller.isFindingNearest
          ? null
          : () {
              ref.read(timeEntryControllerProvider.notifier)
                  .findNearestProject();
            },
      icon: const Icon(Icons.my_location),
      label: Text(
        controller.isFindingNearest ? "Finding…" : controller.findNearestButtonText,
      ),
    );
  }

  // ------------------------------------------------------------
  // FIND LAST JOB
  // ------------------------------------------------------------
  Widget _buildFindLastJob(BuildContext context, WidgetRef ref, TimeEntryController controller) {
    return TextButton.icon(
      onPressed: controller.isFindingLast
          ? null
          : () {
              ref.read(timeEntryControllerProvider.notifier).findLastJob();
            },
      icon: const Icon(Icons.history),
      label: Text(
        controller.isFindingLast ? "Searching…" : "Find Last Job",
      ),
    );
  }

  // ------------------------------------------------------------
  // PROJECT DETAILS CARD
  // ------------------------------------------------------------
  Widget _buildProjectDetails(BuildContext context, WidgetRef ref, TimeEntryController controller) {
    final p = controller.selectedProject!;
    return Card(
      color: Colors.blueGrey.shade900,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Project: ${p.projectName}",
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text("Project Number: ${p.projectNumber}"),
            if (p.town != null) Text("Town: ${p.town}"),
            if (p.county != null) Text("County: ${p.county}"),
            if (p.latitude != null && p.longitude != null)
              Text("GPS: ${p.latitude}, ${p.longitude}"),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------
  // PLANT DETAILS CARD
  // ------------------------------------------------------------
  Widget _buildPlantDetails(BuildContext context, WidgetRef ref, TimeEntryController controller) {
    final plant = controller.selectedPlant!;
    return Card(
      color: Colors.blueGrey.shade900,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Plant: ${plant.plantNo}",
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text("Description: ${plant.shortDescription}"),
          ],
        ),
      ),
    );
  }
}
