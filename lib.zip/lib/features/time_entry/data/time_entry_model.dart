// lib/features/time_entry/data/time_entry_model.dart

import 'package:uuid/uuid.dart';

/// Break entry (max 3 per day)
class TimeBreak {
  final String start;   // "HH:mm"
  final String end;     // "HH:mm"
  final String reason;

  TimeBreak({
    required this.start,
    required this.end,
    required this.reason,
  });

  Map<String, dynamic> toMap() {
    return {
      'break_start': start,
      'break_end': end,
      'reason': reason,
    };
  }
}

/// Main Time Period Model
class TimeEntryModel {
  final String id;

  final String userId;
  final DateTime workDate;           // Date only
  final String startTime;            // HH:mm
  final String finishTime;           // HH:mm

  final String? projectId;           // if working on project
  final String? largePlantId;        // if working on plant

  final List<TimeBreak> breaks;

  // Allowances
  final int travelToSiteMinutes;
  final int travelFromSiteMinutes;
  final int miscAllowanceMinutes;
  final bool onCall;

  // Travel metrics
  final int? travelTimeMinutes;      // total travel time
  final String? travelTimeText;      // "1 hr 10 min"
  final double? distanceKm;          // numeric kilometres

  // Materials (Concrete etc)
  final int? concreteTicketNo;
  final String? concreteMixType;
  final double? concreteQty;

  final String? comments;

  // GPS
  final double? submissionLat;
  final double? submissionLng;
  final int? gpsAccuracy;

  // Flags
  final bool offlineCreated;
  final bool synced;

  // Workflow status
  final String status;               // draft, submitted, approved, rejected
  final int revisionNumber;

  TimeEntryModel({
    String? id,
    required this.userId,
    required this.workDate,
    required this.startTime,
    required this.finishTime,
    this.projectId,
    this.largePlantId,
    required this.breaks,
    required this.travelToSiteMinutes,
    required this.travelFromSiteMinutes,
    required this.miscAllowanceMinutes,
    required this.onCall,
    this.travelTimeMinutes,
    this.travelTimeText,
    this.distanceKm,
    this.concreteTicketNo,
    this.concreteMixType,
    this.concreteQty,
    this.comments,
    this.submissionLat,
    this.submissionLng,
    this.gpsAccuracy,
    this.offlineCreated = false,
    this.synced = false,
    this.status = 'draft',
    this.revisionNumber = 0,
  }) : id = id ?? const Uuid().v4();

  /// Convert into format expected by public.time_periods
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'user_id': userId,
      'work_date': workDate.toIso8601String(),
      'start_time': _combineToTimestamp(workDate, startTime),
      'finish_time': _combineToTimestamp(workDate, finishTime),

      'project_id': projectId,
      'mechanic_large_plant_id': largePlantId,

      'travel_to_site_min': travelToSiteMinutes,
      'travel_from_site_min': travelFromSiteMinutes,
      'misc_allowance_min': miscAllowanceMinutes,
      'on_call': onCall,

      'concrete_ticket_no': concreteTicketNo,
      'concrete_mix_type': concreteMixType,
      'concrete_qty': concreteQty,

      'comments': comments,
      'submission_lat': submissionLat,
      'submission_lng': submissionLng,
      'submission_gps_accuracy': gpsAccuracy,

      'distance_from_home': distanceKm,
      'travel_time_minutes': travelTimeMinutes,
      'travel_time_text': travelTimeText,

      'synced': synced,
      'offline_created': offlineCreated,
      'status': status,
      'revision_number': revisionNumber,
    };
  }

  static String _combineToTimestamp(DateTime date, String hhmm) {
    final parts = hhmm.split(':');
    final hour = int.parse(parts[0]);
    final minute = int.parse(parts[1]);

    final dt = DateTime.utc(
      date.year,
      date.month,
      date.day,
      hour,
      minute,
    );

    return dt.toIso8601String();
  }
}
