// lib/features/time_entry/data/time_entry_repository.dart

import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:dwce_time_tracker/features/time_entry/data/time_entry_model.dart';

class TimeEntryRepository {
  final SupabaseClient _supabase;

  TimeEntryRepository(this._supabase);

  /// Save the main time_periods row
  Future<String> saveTimeEntry(TimeEntryModel entry) async {
    try {
      final map = entry.toMap();

      final response = await _supabase
          .from('time_periods')
          .insert(map)
          .select()
          .single();

      return response['id'] as String;
    } catch (e) {
      throw Exception("Failed to save time entry: $e");
    }
  }

  /// Save breaks to public.time_breaks
  Future<void> saveBreaks(String timePeriodId, List<TimeBreak> breaks) async {
    if (breaks.isEmpty) return;

    final rows = breaks.map((b) {
      return {
        'time_period_id': timePeriodId,
        'break_start': b.start,
        'break_end': b.end,
        'reason': b.reason,
      };
    }).toList();

    try {
      await _supabase.from('time_breaks').insert(rows);
    } catch (e) {
      throw Exception("Failed to save breaks: $e");
    }
  }

  /// Save "used" large plant
  Future<void> saveUsedPlant(String timePeriodId, List<String> largePlantIds) async {
    if (largePlantIds.isEmpty) return;

    final rows = largePlantIds.map((id) {
      return {
        'time_period_id': timePeriodId,
        'large_plant_id': id,
      };
    }).toList();

    try {
      await _supabase.from('time_used_large_plant').insert(rows);
    } catch (e) {
      throw Exception("Failed to save used plant list: $e");
    }
  }

  /// Save "mobilised" large plant
  Future<void> saveMobilisedPlant(String timePeriodId, List<String> plantIds) async {
    if (plantIds.isEmpty) return;

    final rows = plantIds.map((id) {
      return {
        'time_period_id': timePeriodId,
        'large_plant_id': id,
      };
    }).toList();

    try {
      await _supabase.from('time_mobilised_large_plant').insert(rows);
    } catch (e) {
      throw Exception("Failed to save mobilised plant list: $e");
    }
  }

  /// Record a Google API lookup
  Future<void> logGoogleApiCall({
    required String displayName,
    required double homeLat,
    required double homeLng,
    required double projectLat,
    required double projectLng,
    required int travelMinutes,
    required String travelText,
    required double distanceKm,
    required String distanceText,
    required bool wasCached,
  }) async {
    try {
      await _supabase.from('google_api_calls').insert({
        'display_name': displayName,
        'home_latitude': homeLat,
        'home_longitude': homeLng,
        'project_latitude': projectLat,
        'project_longitude': projectLng,
        'travel_time_minutes': travelMinutes,
        'travel_time_formatted': travelText,
        'distance_kilometers': distanceKm,
        'distance_text': distanceText,
        'was_cached': wasCached,
        'time_stamp': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      throw Exception("Failed to log Google API call: $e");
    }
  }

  /// Main "save everything" wrapper
  Future<void> saveCompleteEntry({
    required TimeEntryModel entry,
    required List<TimeBreak> breaks,
    required List<String> usedPlantIds,
    required List<String> mobilisedPlantIds,
  }) async {
    try {
      // 1. Insert main row
      final timePeriodId = await saveTimeEntry(entry);

      // 2. Insert breaks
      await saveBreaks(timePeriodId, breaks);

      // 3. Insert used plant list
      await saveUsedPlant(timePeriodId, usedPlantIds);

      // 4. Insert mobilised plant list
      await saveMobilisedPlant(timePeriodId, mobilisedPlantIds);

    } catch (e) {
      throw Exception("Failed to save complete time entry: $e");
    }
  }
}
