import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../controller/time_entry_controller.dart';

class BreaksSection extends ConsumerWidget {
  const BreaksSection({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(timeEntryControllerProvider.notifier);
    final state = ref.watch(timeEntryControllerProvider);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Breaks", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),

        _timeRow(
          context,
          label: "Break 1",
          startTime: controller.break1Start,
          endTime: controller.break1End,
          onStartTap: () async {
            controller.break1Start = await _pick(context, controller.break1Start);
          },
          onEndTap: () async {
            controller.break1End = await _pick(context, controller.break1End);
          },
        ),

        const SizedBox(height: 12),

        if (!controller.showBreak2)
          TextButton(
            onPressed: () {
              controller.showBreak2 = true;
              ref.read(timeEntryControllerProvider.notifier).state =
                  TimeEntryState.ready();
            },
            child: const Text("Add second break"),
          ),

        if (controller.showBreak2)
          _timeRow(
            context,
            label: "Break 2",
            startTime: controller.break2Start,
            endTime: controller.break2End,
            onStartTap: () async {
              controller.break2Start = await _pick(context, controller.break2Start);
            },
            onEndTap: () async {
              controller.break2End = await _pick(context, controller.break2End);
            },
          ),
      ],
    );
  }

  Widget _timeRow(
    BuildContext context, {
    required String label,
    required TimeOfDay? startTime,
    required TimeOfDay? endTime,
    required VoidCallback onStartTap,
    required VoidCallback onEndTap,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: InkWell(
                onTap: onStartTap,
                child: _box(startTime?.format(context) ?? "--:--"),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: InkWell(
                onTap: onEndTap,
                child: _box(endTime?.format(context) ?? "--:--"),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _box(String text) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade400),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(text),
    );
  }

  Future<TimeOfDay?> _pick(BuildContext context, TimeOfDay? initial) {
    return showTimePicker(
      context: context,
      initialTime: initial ?? const TimeOfDay(hour: 12, minute: 0),
    );
  }
}
