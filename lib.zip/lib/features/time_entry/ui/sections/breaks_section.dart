// lib/features/time_entry/ui/sections/breaks_section.dart

import 'package:flutter/material.dart';
import '../../../../theme/colors.dart';

class BreaksSection extends StatelessWidget {
  final List<Map<String, String>> breaks;
  final VoidCallback onAddBreak;
  final void Function(int) onRemoveBreak;
  final void Function(int, String, String) onEditBreak;

  const BreaksSection({
    super.key,
    required this.breaks,
    required this.onAddBreak,
    required this.onRemoveBreak,
    required this.onEditBreak,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Breaks",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white),
          ),
          const SizedBox(height: 16),

          ..._buildBreakItems(context),

          const SizedBox(height: 12),

          _addBreakButton(),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // UI COMPONENTS
  // ---------------------------------------------------------------------------

  List<Widget> _buildBreakItems(BuildContext context) {
    if (breaks.isEmpty) {
      return [
        const Text(
          "No breaks added",
          style: TextStyle(color: Colors.white70),
        ),
        const SizedBox(height: 12),
      ];
    }

    return List.generate(breaks.length, (index) {
      final item = breaks[index];

      return Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white10,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: _timeField(
                    label: "Start",
                    value: item['start'] ?? "",
                    onChanged: (v) => onEditBreak(index, "start", v),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _timeField(
                    label: "Finish",
                    value: item['finish'] ?? "",
                    onChanged: (v) => onEditBreak(index, "finish", v),
                  ),
                ),
                IconButton(
                  tooltip: "Remove this break",
                  icon: const Icon(Icons.delete_forever, color: Colors.redAccent),
                  onPressed: () => onRemoveBreak(index),
                ),
              ],
            ),
            const SizedBox(height: 10),
            _reasonField(
              value: item['reason'] ?? "",
              onChanged: (v) => onEditBreak(index, "reason", v),
            ),
          ],
        ),
      );
    });
  }

  Widget _timeField({
    required String label,
    required String value,
    required ValueChanged<String> onChanged,
  }) {
    return TextField(
      style: const TextStyle(color: Colors.white),
      keyboardType: TextInputType.datetime,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white70),
        enabledBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white30),
        ),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.greenAccent),
        ),
        hintText: "HH:mm",
        hintStyle: const TextStyle(color: Colors.white30),
      ),
      onChanged: onChanged,
    );
  }

  Widget _reasonField({
    required String value,
    required ValueChanged<String> onChanged,
  }) {
    return TextField(
      maxLines: 2,
      style: const TextStyle(color: Colors.white),
      decoration: const InputDecoration(
        labelText: "Reason (optional)",
        labelStyle: TextStyle(color: Colors.white70),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white30),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.greenAccent),
        ),
      ),
      onChanged: onChanged,
    );
  }

  Widget _addBreakButton() {
    final disabled = breaks.length >= 3;

    return ElevatedButton.icon(
      icon: const Icon(Icons.add),
      label: Text(disabled ? "Maximum 3 breaks allowed" : "Add Break"),
      onPressed: disabled ? null : onAddBreak,
      style: ElevatedButton.styleFrom(
        backgroundColor: disabled ? Colors.grey.shade600 : Colors.green,
        foregroundColor: Colors.white,
      ),
    );
  }
}
