// lib/features/time_entry/ui/sections/project_section.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../providers/all_projects_provider.dart';
import '../../../../providers/all_large_plant_provider.dart';
import '../../../../theme/colors.dart';

class ProjectSection extends ConsumerWidget {
  final bool isMechanic;            // whether user is mechanic (profile flag)
  final bool mechanicMode;          // whether user toggled "Work on Plant"
  final String? selectedProjectId;  // current selected project
  final String? selectedPlantId;    // current selected plant
  final Function(bool) onMechanicModeChanged;
  final Function(String?) onProjectChanged;
  final Function(String?) onPlantChanged;

  const ProjectSection({
    super.key,
    required this.isMechanic,
    required this.mechanicMode,
    required this.selectedProjectId,
    required this.selectedPlantId,
    required this.onMechanicModeChanged,
    required this.onProjectChanged,
    required this.onPlantChanged,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final projectsAsync = ref.watch(allProjectsProvider);
    final plantsAsync = ref.watch(allLargePlantProvider);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          // ------------------------------------------------------------------
          // TITLE
          // ------------------------------------------------------------------
          Row(
            children: const [
              Icon(Icons.engineering, color: Colors.white70),
              SizedBox(width: 8),
              Text(
                "Project / Plant",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // ------------------------------------------------------------------
          // MECHANIC MODE TOGGLE (Mechanics always see this)
          // ------------------------------------------------------------------
          if (isMechanic)
            SwitchListTile(
              value: mechanicMode,
              onChanged: onMechanicModeChanged,
              title: const Text(
                "Work on Plant instead of Project",
                style: TextStyle(color: Colors.white),
              ),
              activeColor: Colors.lightGreenAccent,
              contentPadding: EdgeInsets.zero,
            ),

          if (!isMechanic)
            const SizedBox(height: 8),

          // ------------------------------------------------------------------
          // PROJECT DROPDOWN (if not in mechanic mode)
          // ------------------------------------------------------------------
          if (!mechanicMode)
            projectsAsync.when(
              data: (projects) {
                return DropdownButtonFormField<String>(
                  value: selectedProjectId,
                  decoration: _dropdownDecoration("Select Project"),
                  dropdownColor: AppColors.cardBackground,
                  iconEnabledColor: Colors.white,
                  items: projects.map<DropdownMenuItem<String>>((p) {
                    return DropdownMenuItem(
                      value: p['id'] as String,
                      child: Text(
                        "${p['project_number'] ?? ''} — ${p['project_name']}",
                        style: const TextStyle(color: Colors.white),
                      ),
                    );
                  }).toList(),
                  onChanged: onProjectChanged,
                );
              },
              loading: () => const Center(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: CircularProgressIndicator(),
                ),
              ),
              error: (e, _) => Text(
                "Error loading projects",
                style: TextStyle(color: Colors.redAccent),
              ),
            ),

          // ------------------------------------------------------------------
          // PLANT DROPDOWN (if mechanic OR mechanic mode ON)
          // ------------------------------------------------------------------
          if (mechanicMode)
            plantsAsync.when(
              data: (plants) {
                return DropdownButtonFormField<String>(
                  value: selectedPlantId,
                  decoration: _dropdownDecoration("Select Plant"),
                  dropdownColor: AppColors.cardBackground,
                  iconEnabledColor: Colors.white,
                  items: plants.map<DropdownMenuItem<String>>((p) {
                    return DropdownMenuItem(
                      value: p['id'] as String,
                      child: Text(
                        "${p['large_plant_no']} — ${p['short_description'] ?? ''}",
                        style: const TextStyle(color: Colors.white),
                      ),
                    );
                  }).toList(),
                  onChanged: onPlantChanged,
                );
              },
              loading: () => const Center(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: CircularProgressIndicator(),
                ),
              ),
              error: (e, _) => Text(
                "Error loading plant list",
                style: TextStyle(color: Colors.redAccent),
              ),
            ),
        ],
      ),
    );
  }

  // --------------------------------------------------------------------------
  // STYLING HELPERS
  // --------------------------------------------------------------------------
  InputDecoration _dropdownDecoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.white70),
      filled: true,
      fillColor: AppColors.inputField,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide.none,
      ),
    );
  }
}
