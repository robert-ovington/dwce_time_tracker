// lib/features/time_entry/ui/sections/allowances_section.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../services/google_travel_service.dart';
import '../../../../theme/colors.dart';
import '../../../time_entry/controller/time_entry_controller.dart';

class AllowancesSection extends ConsumerStatefulWidget {
  final String travelToSite;
  final String travelFromSite;
  final String miscellaneous;
  final bool onCall;

  final double? homeLat;
  final double? homeLng;
  final double? projectLat;
  final double? projectLng;

  final ValueChanged<String> onTravelToSiteChanged;
  final ValueChanged<String> onTravelFromSiteChanged;
  final ValueChanged<String> onMiscellaneousChanged;
  final ValueChanged<bool> onOnCallChanged;

  final void Function(int minutes, double km) onCalculated;

  const AllowancesSection({
    super.key,
    required this.travelToSite,
    required this.travelFromSite,
    required this.miscellaneous,
    required this.onCall,
    required this.homeLat,
    required this.homeLng,
    required this.projectLat,
    required this.projectLng,
    required this.onTravelToSiteChanged,
    required this.onTravelFromSiteChanged,
    required this.onMiscellaneousChanged,
    required this.onOnCallChanged,
    required this.onCalculated,
  });

  @override
  ConsumerState<AllowancesSection> createState() => _AllowancesSectionState();
}

class _AllowancesSectionState extends ConsumerState<AllowancesSection> {
  bool _loadingDistance = false;
  String? _distanceText;
  String? _durationText;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Allowances",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white),
          ),
          const SizedBox(height: 16),

          _buildTravelButtons(),

          if (_loadingDistance) ...[
            const SizedBox(height: 12),
            const Center(child: CircularProgressIndicator()),
          ],

          if (_distanceText != null && _durationText != null) ...[
            const SizedBox(height: 12),
            Text(
              "Distance: $_distanceText\nTravel Time: $_durationText",
              style: const TextStyle(color: Colors.white70),
            ),
          ],

          const SizedBox(height: 18),

          _buildDropdowns(),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // TRAVEL CALCULATIONS
  // ---------------------------------------------------------------------------

  Widget _buildTravelButtons() {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.blueGrey.shade700,
      ),
      onPressed: _calculateTravel,
      child: const Text("Calculate Travel From Home"),
    );
  }

  Future<void> _calculateTravel() async {
    if (widget.homeLat == null ||
        widget.homeLng == null ||
        widget.projectLat == null ||
        widget.projectLng == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Home or Project GPS missing")),
      );
      return;
    }

    setState(() => _loadingDistance = true);

    final result = await GoogleTravelService.calculateDistanceAndTime(
      homeLat: widget.homeLat!,
      homeLng: widget.homeLng!,
      destLat: widget.projectLat!,
      destLng: widget.projectLng!,
    );

    setState(() {
      _distanceText = result.distanceText;
      _durationText = result.durationText;
      _loadingDistance = false;
    });

    // Pass calculated numeric values back to controller
    widget.onCalculated(result.durationMinutes, result.distanceKm);
  }

  // ---------------------------------------------------------------------------
  // DROPDOWNS
  // ---------------------------------------------------------------------------

  Widget _buildDropdowns() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _numberField(
          label: "Travel To Site (minutes)",
          value: widget.travelToSite,
          onChanged: widget.onTravelToSiteChanged,
        ),
        const SizedBox(height: 16),
        _numberField(
          label: "Travel From Site (minutes)",
          value: widget.travelFromSite,
          onChanged: widget.onTravelFromSiteChanged,
        ),
        const SizedBox(height: 16),
        _numberField(
          label: "Misc Allowance (minutes)",
          value: widget.miscellaneous,
          onChanged: widget.onMiscellaneousChanged,
        ),
        const SizedBox(height: 16),
        SwitchListTile(
          title: const Text("On Call", style: TextStyle(color: Colors.white)),
          value: widget.onCall,
          activeColor: Colors.green,
          onChanged: widget.onOnCallChanged,
        ),
      ],
    );
  }

  Widget _numberField({
    required String label,
    required String value,
    required ValueChanged<String> onChanged,
  }) {
    return TextField(
      keyboardType: TextInputType.number,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white70),
        enabledBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white30),
        ),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.greenAccent),
        ),
      ),
      onChanged: onChanged,
    );
  }
}
