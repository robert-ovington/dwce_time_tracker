// lib/features/time_entry/ui/sections/materials_section.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../providers/concrete_mix_provider.dart';
import '../../../../theme/colors.dart';

class MaterialsSection extends ConsumerWidget {
  final String ticketNumber;
  final String concreteMixId;
  final String quantity;

  final ValueChanged<String> onTicketChanged;
  final ValueChanged<String> onMixChanged;
  final ValueChanged<String> onQtyChanged;

  const MaterialsSection({
    super.key,
    required this.ticketNumber,
    required this.concreteMixId,
    required this.quantity,
    required this.onTicketChanged,
    required this.onMixChanged,
    required this.onQtyChanged,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mixList = ref.watch(concreteMixListProvider).value ?? [];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Concrete / Materials",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white),
          ),
          const SizedBox(height: 20),

          _textField(
            label: "Ticket Number",
            value: ticketNumber,
            onChanged: onTicketChanged,
            keyboard: TextInputType.number,
          ),
          const SizedBox(height: 18),

          _mixDropdown(mixList),
          const SizedBox(height: 18),

          _textField(
            label: "Quantity",
            value: quantity,
            onChanged: onQtyChanged,
            keyboard: TextInputType.number,
          ),
        ],
      ),
    );
  }

  // -------------------------------------------------------------------------
  // WIDGETS
  // -------------------------------------------------------------------------

  Widget _textField({
    required String label,
    required String value,
    required ValueChanged<String> onChanged,
    TextInputType keyboard = TextInputType.text,
  }) {
    return TextField(
      style: const TextStyle(color: Colors.white),
      keyboardType: keyboard,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: Colors.white70),
        enabledBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white30),
        ),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.greenAccent),
        ),
      ),
      onChanged: onChanged,
    );
  }

  Widget _mixDropdown(List<Map<String, dynamic>> list) {
    return DropdownButtonFormField<String>(
      value: concreteMixId.isEmpty ? null : concreteMixId,
      dropdownColor: AppColors.cardBackground,
      decoration: const InputDecoration(
        labelText: "Concrete Mix Type",
        labelStyle: TextStyle(color: Colors.white70),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white30),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.greenAccent),
        ),
      ),
      items: list.map((mix) {
        return DropdownMenuItem(
          value: mix['id'],
          child: Text(
            mix['user_description'] ?? mix['turbo_description'] ?? "Mix",
            style: const TextStyle(color: Colors.white),
          ),
        );
      }).toList(),
      onChanged: (val) {
        if (val != null) onMixChanged(val);
      },
    );
  }
}
