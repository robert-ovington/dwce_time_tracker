// lib/features/time_entry/ui/sections/fleet_section.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../providers/user_setup_provider.dart';
import '../../../../theme/colors.dart';

class FleetSection extends ConsumerWidget {
  final List<String> usedFleet;
  final List<String> mobilisedFleet;

  final void Function(List<String>) onUsedFleetChanged;
  final void Function(List<String>) onMobilisedFleetChanged;

  const FleetSection({
    super.key,
    required this.usedFleet,
    required this.mobilisedFleet,
    required this.onUsedFleetChanged,
    required this.onMobilisedFleetChanged,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(userSetupProvider).value;

    if (!_securityAllowsFleet(user)) {
      return const SizedBox.shrink();
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _header(),

          const SizedBox(height: 16),

          _usedFleetDropdown(),

          const SizedBox(height: 16),

          _mobilisedFleetDropdown(),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // HEADER
  // ---------------------------------------------------------------------------
  Widget _header() {
    return const Text(
      "Fleet Used",
      style: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w600,
        color: Colors.white,
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // USED FLEET SELECTION
  // ---------------------------------------------------------------------------
  Widget _usedFleetDropdown() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _fetchPlant(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }

        final plantList = snapshot.data!;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Plant Used",
              style: TextStyle(color: Colors.white),
            ),
            const SizedBox(height: 6),
            _multiSelectChip(
              label: "Select Plant Used",
              items: plantList.map((e) => e['large_plant_no'] as String).toList(),
              selected: usedFleet,
              onChanged: onUsedFleetChanged,
            ),
          ],
        );
      },
    );
  }

  // ---------------------------------------------------------------------------
  // MOBILISED FLEET SELECTION
  // ---------------------------------------------------------------------------
  Widget _mobilisedFleetDropdown() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _fetchPlant(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }

        final plantList = snapshot.data!;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Plant Mobilised",
              style: TextStyle(color: Colors.white),
            ),
            const SizedBox(height: 6),
            _multiSelectChip(
              label: "Select Mobilised Plant",
              items: plantList.map((e) => e['large_plant_no'] as String).toList(),
              selected: mobilisedFleet,
              onChanged: onMobilisedFleetChanged,
            ),
          ],
        );
      },
    );
  }

  // ---------------------------------------------------------------------------
  // MULTI SELECT CHIPS
  // ---------------------------------------------------------------------------
  Widget _multiSelectChip({
    required String label,
    required List<String> items,
    required List<String> selected,
    required Function(List<String>) onChanged,
  }) {
    return Wrap(
      spacing: 6,
      runSpacing: -8,
      children: items.map((item) {
        final isSelected = selected.contains(item);

        return FilterChip(
          label: Text(item),
          selected: isSelected,
          selectedColor: Colors.green.withOpacity(0.3),
          backgroundColor: Colors.white12,
          checkmarkColor: Colors.white,
          labelStyle: const TextStyle(color: Colors.white),
          onSelected: (value) {
            final updated = List<String>.from(selected);
            if (value) {
              updated.add(item);
            } else {
              updated.remove(item);
            }
            onChanged(updated);
          },
        );
      }).toList(),
    );
  }

  // ---------------------------------------------------------------------------
  // DATABASE FETCH
  // ---------------------------------------------------------------------------
  Future<List<Map<String, dynamic>>> _fetchPlant() async {
    final supabase = Supabase.instance.client;

    return await supabase
        .from('large_plant')
        .select()
        .eq('is_active', true)
        .order('large_plant_no', ascending: true);
  }

  // ---------------------------------------------------------------------------
  // SECURITY RULES
  // ---------------------------------------------------------------------------
  bool _securityAllowsFleet(Map<String, dynamic>? setup) {
    if (setup == null) return false;

    final int security = setup['security'];

    // Allowed: 3–7
    // Not allowed: Subcontractor (0), Admin (1), Manager (2), External (8), Client (9)
    return security >= 3 && security <= 7;
  }
}
