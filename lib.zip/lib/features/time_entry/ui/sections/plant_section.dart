import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../providers/large_plant_provider.dart';

class PlantSection extends ConsumerWidget {
  final bool usePlantMode;
  final Function(bool) onPlantModeChanged;

  final String? selectedPlantId;
  final Function(String?) onPlantChanged;

  const PlantSection({
    super.key,
    required this.usePlantMode,
    required this.onPlantModeChanged,
    required this.selectedPlantId,
    required this.onPlantChanged,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Toggle Row
        Row(
          children: [
            Switch(
              value: usePlantMode,
              activeColor: Colors.green,
              onChanged: (value) => onPlantModeChanged(value),
            ),
            const SizedBox(width: 8),
            const Text(
              "Work on Plant instead of Project",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),

        const SizedBox(height: 8),

        // Only show dropdown **if plant mode enabled**
        if (usePlantMode) _buildPlantDropdown(ref),
      ],
    );
  }

  Widget _buildPlantDropdown(WidgetRef ref) {
    final plantListAsync = ref.watch(activeLargePlantProvider);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Select Large Plant",
          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 8),

        plantListAsync.when(
          data: (plants) {
            if (plants.isEmpty) {
              return const Text("No active large plant found.");
            }

            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey.shade600),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: selectedPlantId,
                  isExpanded: true,
                  dropdownColor: Colors.grey.shade900,
                  hint: const Text("Choose plant"),
                  items: plants.map((p) {
                    return DropdownMenuItem(
                      value: p.id,
                      child: Text("${p.largePlantNo} — ${p.largePlantDescription}"),
                    );
                  }).toList(),
                  onChanged: (value) => onPlantChanged(value),
                ),
              ),
            );
          },
          loading: () =>
              const Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator()),
          error: (e, _) =>
              Text("Error loading plant list: $e", style: const TextStyle(color: Colors.red)),
        ),
      ],
    );
  }
}
