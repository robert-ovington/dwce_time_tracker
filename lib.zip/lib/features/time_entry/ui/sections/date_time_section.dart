import 'package:flutter/material.dart';

class DateTimeSection extends StatelessWidget {
  final DateTime workDate;
  final TimeOfDay startTime;
  final TimeOfDay finishTime;

  final ValueChanged<DateTime> onDateChanged;
  final ValueChanged<TimeOfDay> onStartChanged;
  final ValueChanged<TimeOfDay> onFinishChanged;

  const DateTimeSection({
    super.key,
    required this.workDate,
    required this.startTime,
    required this.finishTime,
    required this.onDateChanged,
    required this.onStartChanged,
    required this.onFinishChanged,
  });

  Future<void> _pickDate(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: workDate,
      firstDate: DateTime(2023),
      lastDate: DateTime(2100),
    );
    if (picked != null) onDateChanged(picked);
  }

  Future<void> _pickTime(
    BuildContext context,
    TimeOfDay initial,
    ValueChanged<TimeOfDay> onChanged,
  ) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: initial,
      builder: (context, child) {
        // Forces 24-hour format
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: child!,
        );
      },
    );
    if (picked != null) onChanged(picked);
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Date & Time",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),

            /// --------------------------
            /// SELECT WORK DATE
            /// --------------------------
            Row(
              children: [
                const Expanded(child: Text("Work Date")),
                TextButton(
                  onPressed: () => _pickDate(context),
                  child: Text(
                    "${workDate.year}-${workDate.month.toString().padLeft(2, '0')}-${workDate.day.toString().padLeft(2, '0')}",
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ],
            ),

            const Divider(height: 30),

            /// --------------------------
            /// START TIME
            /// --------------------------
            Row(
              children: [
                const Expanded(child: Text("Start Time")),
                TextButton(
                  onPressed: () =>
                      _pickTime(context, startTime, onStartChanged),
                  child: Text(
                    startTime.format(context),
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ],
            ),

            /// --------------------------
            /// FINISH TIME
            /// --------------------------
            Row(
              children: [
                const Expanded(child: Text("Finish Time")),
                TextButton(
                  onPressed: () =>
                      _pickTime(context, finishTime, onFinishChanged),
                  child: Text(
                    finishTime.format(context),
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
