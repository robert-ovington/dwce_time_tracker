import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../controller/time_entry_controller.dart';
import '../../../../theme/colors.dart';

class EmployeeSelector extends ConsumerWidget {
  const EmployeeSelector({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(timeEntryControllerProvider);
    final controller = ref.read(timeEntryControllerProvider.notifier);

    // If user cannot enter for others, hide the selector.
    if (!state.canEnterForOthers) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: _box,
        child: Row(
          children: [
            const Icon(Icons.person, color: Colors.black54),
            const SizedBox(width: 12),
            Text(
              state.employeeName ?? "Unknown User",
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _box,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("Employee",
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),

          DropdownButtonFormField<String>(
            value: state.selectedEmployeeEmail,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
            ),
            items: [
              for (final u in state.allEmployees)
                DropdownMenuItem(
                  value: u.email,
                  child: Text(u.displayName ?? u.email),
                )
            ],
            onChanged: controller.setSelectedEmployee,
          ),
        ],
      ),
    );
  }

  BoxDecoration get _box => BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.black12),
      );
}
