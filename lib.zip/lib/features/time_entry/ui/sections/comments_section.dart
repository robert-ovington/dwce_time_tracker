import 'package:flutter/material.dart';

class CommentsSection extends StatelessWidget {
  final String? comments;
  final void Function(String?) onChanged;

  const CommentsSection({
    super.key,
    required this.comments,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Comments / Notes",
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),

        TextFormField(
          initialValue: comments ?? "",
          onChanged: (v) => onChanged(v.trim().isEmpty ? null : v),
          maxLines: 5,
          minLines: 3,
          decoration: InputDecoration(
            hintText: "Add comments or job-specific notes...",
            filled: true,
            fillColor: Colors.black26,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),

        const SizedBox(height: 4),

        Text(
          "Optional — used for clarifications or project notes.",
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey.shade400,
          ),
        ),
      ],
    );
  }
}
