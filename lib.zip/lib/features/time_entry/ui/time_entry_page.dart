// lib/features/time_entry/ui/time_entry_page.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../providers/connectivity_provider.dart';
import '../../../providers/sync_queue_provider.dart';
import '../../../providers/user_setup_provider.dart';
import '../../../theme/colors.dart';

import '../../time_entry/controller/time_entry_controller.dart';
import 'sections/date_time_section.dart';
import 'sections/breaks_section.dart';
import 'sections/employee_selector.dart';
import 'sections/project_section.dart';
import 'sections/fleet_section.dart';
import 'sections/allowances_section.dart';
import '../widgets/comments_section.dart';
import '../widgets/materials_section.dart';

class TimeEntryPage extends ConsumerWidget {
  const TimeEntryPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.watch(timeEntryControllerProvider.notifier);
    final state = ref.watch(timeEntryControllerProvider);

    final isOnline = ref.watch(connectivityProvider);
    final pendingCount = ref.watch(pendingSyncCountProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.cardBackground,
        title: const Text("Time Entry"),
        actions: [
          if (!isOnline)
            const Padding(
              padding: EdgeInsets.only(right: 16),
              child: Icon(Icons.cloud_off, color: Colors.redAccent),
            ),
        ],
      ),

      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [

          // -------------------------------------------------------------------
          // OFFLINE BANNER
          // -------------------------------------------------------------------
          if (!isOnline)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.redAccent),
              ),
              child: Row(
                children: [
                  const Icon(Icons.wifi_off, color: Colors.redAccent),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      "You are offline. Entries will be saved locally.",
                      style: TextStyle(color: Colors.redAccent.shade100),
                    ),
                  ),
                ],
              ),
            ),

          if (isOnline && pendingCount > 0)
            ElevatedButton.icon(
              onPressed: () => ref.read(syncQueueProvider.notifier).syncNow(),
              icon: const Icon(Icons.cloud_upload),
              label: Text("Sync Pending Entries ($pendingCount)"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
              ),
            ),

          const SizedBox(height: 16),

          // -------------------------------------------------------------------
          // EMPLOYEE SELECTOR
          // -------------------------------------------------------------------
          EmployeeSelector(
            selectedEmployeeId: state.selectedEmployeeId,
            onChange: controller.setEmployee,
          ),

          const SizedBox(height: 16),

          // -------------------------------------------------------------------
          // DATE - TIME - START/FINISH
          // -------------------------------------------------------------------
          DateTimeSection(
            workDate: state.workDate,
            startTime: state.startTime,
            finishTime: state.finishTime,
            onDateChanged: controller.setWorkDate,
            onStartChanged: controller.setStartTime,
            onFinishChanged: controller.setFinishTime,
          ),

          const SizedBox(height: 16),

          // -------------------------------------------------------------------
          // PROJECT or PLANT SELECTOR
          // -------------------------------------------------------------------
          ProjectSection(
            isMechanic: state.isMechanic,
            mechanicMode: state.mechanicMode,
            selectedProjectId: state.selectedProjectId,
            selectedPlantId: state.selectedPlantId,
            onMechanicModeChanged: controller.setMechanicMode,
            onProjectChanged: controller.setProject,
            onPlantChanged: controller.setPlant,
          ),

          const SizedBox(height: 16),

          // -------------------------------------------------------------------
          // FLEET SECTION (if allowed)
          // -------------------------------------------------------------------
          if (state.showFleetSection)
            FleetSection(
              usedFleet: state.usedFleet,
              mobilisedFleet: state.mobilisedFleet,
              onUsedFleetChanged: controller.setUsedFleet,
              onMobilisedFleetChanged: controller.setMobilisedFleet,
              onSaveFleet: controller.saveFleetToProfile,
              onClearFleet: controller.clearSavedFleet,
              onRecallFleet: controller.recallFleetFromProfile,
            ),

          const SizedBox(height: 16),

          // -------------------------------------------------------------------
          // ALLOWANCES SECTION (travel, misc)
          // -------------------------------------------------------------------
          AllowancesSection(
            travelToSiteMin: state.travelToSiteMin,
            travelFromSiteMin: state.travelFromSiteMin,
            miscAllowanceMin: state.miscAllowanceMin,
            onTravelToChanged: controller.setTravelToSite,
            onTravelFromChanged: controller.setTravelFromSite,
            onMiscChanged: controller.setMiscAllowance,
          ),

          const SizedBox(height: 16),

          // -------------------------------------------------------------------
          // MATERIALS SECTION (only for concrete-mix lorry users)
          // -------------------------------------------------------------------
          if (state.showMaterialsSection)
            MaterialsSection(
              ticketNumber: state.ticketNumber,
              concreteMixId: state.concreteMixId,
              quantity: state.quantity,
              onTicketChanged: controller.setTicketNumber,
              onMixChanged: controller.setConcreteMix,
              onQtyChanged: controller.setQuantity,
              maxTicketNumber: state.maxTicketNumber,
            ),

          const SizedBox(height: 16),

          // -------------------------------------------------------------------
          // BREAKS SECTION
          // -------------------------------------------------------------------
          BreaksSection(
            breaks: state.breaks,
            onAddBreak: controller.addBreak,
            onRemoveBreak: controller.removeBreak,
            onEditBreak: controller.editBreak,
          ),

          const SizedBox(height: 16),

          // -------------------------------------------------------------------
          // COMMENTS
          // -------------------------------------------------------------------
          CommentsSection(
            comments: state.comments,
            onChanged: controller.setComments,
          ),

          const SizedBox(height: 32),

          // -------------------------------------------------------------------
          // SAVE BUTTON
          // -------------------------------------------------------------------
          ElevatedButton.icon(
            onPressed: state.isSaving ? null : () async {
              final success = await controller.saveTimeEntry();

              if (success && context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Time Period Saved"),
                    backgroundColor: Colors.green,
                  ),
                );
              }
            },
            icon: state.isSaving
                ? const SizedBox(
                    height: 18,
                    width: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.upload),
            label: Text(state.isSaving ? "Saving..." : "Save Time Period"),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.greenAccent.shade700,
              padding: const EdgeInsets.symmetric(vertical: 16),
              textStyle: const TextStyle(fontSize: 16),
            ),
          ),

          const SizedBox(height: 50),
        ],
      ),
    );
  }
}
