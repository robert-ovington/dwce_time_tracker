import 'package:flutter/material.dart';

/// Generates 96 quarter-hour increments from 00:00 → 23:45
List<DropdownMenuItem<TimeOfDay>> buildTimeDropdownItems() {
  List<DropdownMenuItem<TimeOfDay>> items = [];

  for (int i = 0; i < 24 * 4; i++) {
    final hour = i ~/ 4;
    final minute = (i % 4) * 15;

    final time = TimeOfDay(hour: hour, minute: minute);
    final label = time.format(
      const TimeOfDayFormat.H_colon_mm, // always HH:mm
    );

    items.add(
      DropdownMenuItem(
        value: time,
        child: Text(
          "${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}",
        ),
      ),
    );
  }

  return items;
}

/// Nullable version (for break start/end)
List<DropdownMenuItem<TimeOfDay?>> buildNullableTimeDropdownItems() {
  return [
    const DropdownMenuItem(
      value: null,
      child: Text("None"),
    ),
    ...buildTimeDropdownItems().map(
      (item) => DropdownMenuItem<TimeOfDay?>(
        value: item.value,
        child: item.child,
      ),
    )
  ];
}

/// Convert TimeOfDay → proper TIMESTAMPTZ string
String convertToTimestamp(DateTime date, TimeOfDay tod) {
  final dt = DateTime(
    date.year,
    date.month,
    date.day,
    tod.hour,
    tod.minute,
  );
  return dt.toIso8601String();
}
