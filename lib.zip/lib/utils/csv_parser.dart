import 'dart:convert';

class CsvRow {
  final Map<String, String> fields;
  CsvRow(this.fields);
}

/// Parses CSV text into a list of CsvRow objects.
///
/// Automatically trims whitespace and lowercases column headers.
/// Assumes first row is header row.
List<CsvRow> parseCsv(String csvText) {
  final lines = const LineSplitter().convert(csvText);

  if (lines.isEmpty) return [];

  final header = lines.first.split(',').map((e) => e.trim().toLowerCase()).toList();

  final rows = <CsvRow>[];

  for (var i = 1; i < lines.length; i++) {
    final parts = lines[i].split(',');

    final map = <String, String>{};

    for (var j = 0; j < header.length && j < parts.length; j++) {
      map[header[j]] = parts[j].trim();
    }

    rows.add(CsvRow(map));
  }

  return rows;
}
