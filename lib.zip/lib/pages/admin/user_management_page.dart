import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../providers/user_setup_provider.dart';

class UserManagementPage extends ConsumerStatefulWidget {
  const UserManagementPage({super.key});

  @override
  ConsumerState<UserManagementPage> createState() =>
      _UserManagementPageState();
}

class _UserManagementPageState extends ConsumerState<UserManagementPage> {
  String _search = "";
  bool _loading = false;
  List<Map<String, dynamic>> _allUsers = [];
  List<Map<String, dynamic>> _filtered = [];

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  Future<void> _loadUsers() async {
    setState(() => _loading = true);

    final supabase = Supabase.instance.client;

    try {
      final data = await supabase
          .from('users_setup')
          .select('user_id, display_name, role, security')
          .order('display_name');

      final users = List<Map<String, dynamic>>.from(data);

      setState(() {
        _allUsers = users;
        _filtered = users;
      });
    } catch (e) {
      debugPrint("Error loading users: $e");
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _applySearch(String value) {
    setState(() {
      _search = value.toLowerCase().trim();
      _filtered = _allUsers.where((u) {
        final name = u['display_name'].toString().toLowerCase();
        final role = u['role'].toString().toLowerCase();
        return name.contains(_search) || role.contains(_search);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final userSetup = ref.watch(userSetupProvider).value;
    if (userSetup == null) {
      return Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final int security = int.tryParse(userSetup['security'].toString()) ?? 9;

    // Restrict access
    if (security > 2) {
      return Scaffold(
        appBar: AppBar(title: const Text("User Management")),
        body: const Center(
          child: Text(
            "Access denied",
            style: TextStyle(fontSize: 18, color: Colors.redAccent),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("User Management"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadUsers,
          )
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Search bar
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: TextField(
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.search),
                  hintText: "Search by name or role",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onChanged: _applySearch,
              ),
            ),

            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _filtered.isEmpty
                      ? const Center(child: Text("No users found"))
                      : ListView.separated(
                          itemCount: _filtered.length,
                          separatorBuilder: (_, __) => Divider(height: 1),
                          itemBuilder: (context, index) {
                            final u = _filtered[index];

                            return ListTile(
                              title: Text(u['display_name']),
                              subtitle: Text(
                                  "${u['role']} — Security ${u['security']}"),
                              leading: const Icon(Icons.person),
                              trailing: const Icon(Icons.arrow_forward_ios),
                              onTap: () {
                                Navigator.pushNamed(
                                  context,
                                  '/profile',
                                  arguments: u['user_id'],
                                );
                              },
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}
