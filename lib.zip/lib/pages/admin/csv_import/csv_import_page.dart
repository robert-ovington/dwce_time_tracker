import 'dart:html' as html;   // Web file picker
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../providers/csv_import_provider.dart';
import 'csv_preview_page.dart';

class CsvImportPage extends ConsumerWidget {
  const CsvImportPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text("Import Users (CSV)")),
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            final upload = html.FileUploadInputElement()..accept = '.csv';
            upload.click();

            upload.onChange.listen((event) {
              final file = upload.files?.first;
              final reader = html.FileReader();

              reader.readAsText(file!);
              reader.onLoadEnd.listen((_) {
                final content = reader.result as String;

                ref.read(csvImportProvider.notifier).loadCsv(content);

                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const CsvPreviewPage()),
                );
              });
            });
          },
          child: const Text("Choose CSV File"),
        ),
      ),
    );
  }
}
