import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../providers/csv_import_provider.dart';
import 'csv_edit_row_page.dart';
import 'csv_import_results_page.dart';
import '../../../providers/create_user_provider.dart';

class CsvPreviewPage extends ConsumerWidget {
  const CsvPreviewPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(csvImportProvider);

    return Scaffold(
      appBar: AppBar(title: const Text("Preview CSV Data")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            if (state.errors.isNotEmpty) ...[
              const Text("Errors found:", style: TextStyle(fontSize: 18)),
              const SizedBox(height: 8),
              ...state.errors.map((e) =>
                  Text(e, style: const TextStyle(color: Colors.red))),
              const SizedBox(height: 20),
              const Text("Fix errors before importing.",
                  style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
            ],
            Expanded(
              child: ListView.builder(
                itemCount: state.rows.length,
                itemBuilder: (_, i) {
                  final row = state.rows[i].fields;

                  return Card(
                    elevation: 1,
                    child: ListTile(
                      title: Text("${row['surname']}, ${row['forename']}"),
                      subtitle: Text(row['email'] ?? ''),
                      trailing: IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  CsvEditRowPage(rowIndex: i, row: state.rows[i]),
                            ),
                          );
                        },
                      ),
                    ),
                  );
                },
              ),
            ),
            ElevatedButton(
              onPressed: state.readyToImport
                  ? () async {
                      final results = await _runImports(ref);
                      if (context.mounted) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CsvImportResultsPage(results: results),
                          ),
                        );
                      }
                    }
                  : null,
              child: const Text("Import All"),
            ),
          ],
        ),
      ),
    );
  }

  Future<List<Map<String, dynamic>>> _runImports(WidgetRef ref) async {
    final rows = ref.read(csvImportProvider).rows;
    final controller = ref.read(createUserProvider.notifier);

    final results = <Map<String, dynamic>>[];

    for (final row in rows) {
      final f = row.fields;

      try {
        await controller.createUser(
          forename: f['forename']!,
          surname: f['surname']!,
          initials: f['initials']!,
          email: f['email']!,
          phone: f['phone']?.isEmpty ?? true ? null : f['phone'],
          role: f['role']!,
          security: int.parse(f['security']!),
          password: (f['password']?.isEmpty ?? true) ? null : f['password'],
          sendInvite: (f['password']?.isEmpty ?? true),
        );

        results.add({'status': 'success', 'email': f['email']!});
      } catch (err) {
        results.add({
          'status': 'error',
          'email': f['email']!,
          'message': err.toString(),
        });
      }
    }

    return results;
  }
}
