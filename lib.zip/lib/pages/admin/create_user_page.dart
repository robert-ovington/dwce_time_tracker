import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/create_user_provider.dart';

class CreateUserPage extends ConsumerStatefulWidget {
  const CreateUserPage({super.key});

  @override
  ConsumerState<CreateUserPage> createState() => _CreateUserPageState();
}

class _CreateUserPageState extends ConsumerState<CreateUserPage> {
  final _formKey = GlobalKey<FormState>();

  final _forenameController = TextEditingController();
  final _surnameController = TextEditingController();
  final _initialsController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();

  String? _selectedRole;
  int? _selectedSecurity;
  bool _sendInvite = true;

  // These are your ENUM roles EXACTLY as defined:
  final roleOptions = const [
    'Admin',
    'Manager',
    'Supervisor',
    'PICW',
    'Driver',
    'Fitter',
    'Mechanic',
    'User',
    'Subcontractor',
    'External',
  ];

  @override
  Widget build(BuildContext context) {
    final createState = ref.watch(createUserProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Create New User'),
        elevation: 2,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                const Text(
                  "User Details",
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 18),

                TextFormField(
                  controller: _forenameController,
                  decoration: const InputDecoration(
                    labelText: 'Forename',
                    border: OutlineInputBorder(),
                  ),
                  validator: (val) =>
                      val == null || val.isEmpty ? 'Enter forename' : null,
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _surnameController,
                  decoration: const InputDecoration(
                    labelText: 'Surname',
                    border: OutlineInputBorder(),
                  ),
                  validator: (val) =>
                      val == null || val.isEmpty ? 'Enter surname' : null,
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _initialsController,
                  decoration: const InputDecoration(
                    labelText: 'Initials',
                    border: OutlineInputBorder(),
                  ),
                  validator: (val) =>
                      val == null || val.isEmpty ? 'Enter initials' : null,
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    border: OutlineInputBorder(),
                  ),
                  validator: (val) =>
                      val == null || !val.contains('@') ? 'Invalid email' : null,
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _phoneController,
                  decoration: const InputDecoration(
                    labelText: 'Phone (optional)',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),

                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: "Role",
                    border: OutlineInputBorder(),
                  ),
                  items: roleOptions
                      .map((r) => DropdownMenuItem(value: r, child: Text(r)))
                      .toList(),
                  value: _selectedRole,
                  onChanged: (v) => setState(() => _selectedRole = v),
                  validator: (val) =>
                      val == null ? 'Select a role' : null,
                ),
                const SizedBox(height: 16),

                TextFormField(
                  decoration: const InputDecoration(
                    labelText: 'Security Level (1–9)',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                  onChanged: (val) {
                    final parsed = int.tryParse(val);
                    if (parsed != null) {
                      _selectedSecurity = parsed;
                    }
                  },
                  validator: (val) {
                    final parsed = int.tryParse(val ?? '');
                    if (parsed == null || parsed < 1 || parsed > 9) {
                      return 'Enter a number between 1 and 9';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                SwitchListTile(
                  title: const Text("Send email invite (ignore password)"),
                  value: _sendInvite,
                  onChanged: (v) {
                    setState(() => _sendInvite = v);
                  },
                ),
                const SizedBox(height: 16),

                if (!_sendInvite)
                  TextFormField(
                    controller: _passwordController,
                    decoration: const InputDecoration(
                      labelText: 'Password (optional)',
                      border: OutlineInputBorder(),
                    ),
                  ),

                const SizedBox(height: 32),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: createState.isLoading
                        ? null
                        : () async {
                            if (!_formKey.currentState!.validate()) {
                              return;
                            }

                            try {
                              await ref
                                  .read(createUserProvider.notifier)
                                  .createUser(
                                    forename: _forenameController.text.trim(),
                                    surname: _surnameController.text.trim(),
                                    initials: _initialsController.text.trim(),
                                    email: _emailController.text.trim(),
                                    phone: _phoneController.text.trim().isEmpty
                                        ? null
                                        : _phoneController.text.trim(),
                                    role: _selectedRole!,
                                    security: _selectedSecurity!,
                                    password: _sendInvite
                                        ? null
                                        : _passwordController.text.trim(),
                                    sendInvite: _sendInvite,
                                  );

                              if (mounted) {
                                showDialog(
                                  context: context,
                                  builder: (_) => AlertDialog(
                                    title: const Text("Success"),
                                    content: Text(
                                        "User \"${_surnameController.text}, ${_forenameController.text}\" created successfully."),
                                    actions: [
                                      TextButton(
                                        onPressed: () {
                                          Navigator.pop(context);
                                        },
                                        child: const Text("OK"),
                                      )
                                    ],
                                  ),
                                );
                              }
                            } catch (err) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content:
                                      Text(err.toString().replaceAll("Exception:", "").trim()),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          },
                    child: createState.isLoading
                        ? const CircularProgressIndicator()
                        : const Text(
                            'Create User',
                            style: TextStyle(fontSize: 18),
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
