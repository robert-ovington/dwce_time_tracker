import 'package:flutter/material.dart';

class PrestartChecksPage extends StatelessWidget {
  const PrestartChecksPage({super.key});

  @override
  Widget build(BuildContext context) {
    return _placeholder(context, "Large Plant Pre-Start Checks");
  }
}
