import 'package:flutter/material.dart';

class RecordMaterialsPage extends StatelessWidget {
  const RecordMaterialsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return _placeholder(context, "Record Materials");
  }
}
