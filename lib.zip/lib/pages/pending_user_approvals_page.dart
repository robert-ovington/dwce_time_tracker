import 'package:flutter/material.dart';

class PendingUserApprovalsPage extends StatelessWidget {
  const PendingUserApprovalsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return _placeholder(context, "Pending User Approvals");
  }
}
