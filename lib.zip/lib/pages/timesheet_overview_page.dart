import 'package:flutter/material.dart';

class TimesheetOverviewPage extends StatelessWidget {
  const TimesheetOverviewPage({super.key});

  @override
  Widget build(BuildContext context) {
    return _placeholder(context, "Timesheet Overview");
  }
}

Widget _placeholder(BuildContext context, String title) {
  return Scaffold(
    appBar: AppBar(
      title: Text(title),
      leading: IconButton(
        icon: const Icon(Icons.home),
        onPressed: () => Navigator.pushReplacementNamed(context, "/home"),
      ),
    ),
    body: Center(
      child: Text(
        "$title\nFeature coming soon",
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 22),
      ),
    ),
  );
}
