import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../providers/system_settings_provider.dart';
import '../../providers/user_data_provider.dart';

class TermsPage extends ConsumerStatefulWidget {
  const TermsPage({super.key});

  @override
  ConsumerState<TermsPage> createState() => _TermsPageState();
}

class _TermsPageState extends ConsumerState<TermsPage> {
  bool _acceptChecked = false;
  bool _saving = false;

  Future<void> _acceptTerms() async {
    setState(() => _saving = true);

    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;

    if (user == null) return;

    final now = DateTime.now().toIso8601String();

    try {
      await supabase
          .from('users_data')
          .update({'terms_accepted_date': now})
          .eq('user_id', user.id);

      if (mounted) {
        Navigator.pushReplacementNamed(context, '/home');
      }
    } catch (e) {
      debugPrint("Error updating terms acceptance: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Error saving acceptance. Try again.")),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final sysSettings = ref.watch(systemSettingsProvider);
    final termsText = sysSettings.value?['terms_text'] ??
        "DWCE Terms & Conditions will appear here.";

    return Scaffold(
      appBar: AppBar(
        title: const Text("Terms & Conditions"),
        automaticallyImplyLeading: false, // Prevent back navigation
      ),
      body: SafeArea(
        child: Column(
          children: [
            // ───────────────────────────────────────────────────────────
            // Logo
            // ───────────────────────────────────────────────────────────
            const SizedBox(height: 20),
            SizedBox(
              height: 60,
              child: Image.asset(
                'assets/logo/dwce_logo.png',
                fit: BoxFit.contain,
              ),
            ),
            const SizedBox(height: 20),

            // ───────────────────────────────────────────────────────────
            // Terms body (scrollable)
            // ───────────────────────────────────────────────────────────
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: SingleChildScrollView(
                  child: Text(
                    termsText,
                    style: const TextStyle(fontSize: 16, height: 1.4),
                  ),
                ),
              ),
            ),

            // ───────────────────────────────────────────────────────────
            // Accept Checkbox
            // ───────────────────────────────────────────────────────────
            CheckboxListTile(
              value: _acceptChecked,
              onChanged: (v) {
                setState(() => _acceptChecked = v ?? false);
              },
              title: const Text(
                "I have read and accept the Terms & Conditions.",
              ),
            ),

            const SizedBox(height: 8),

            // ───────────────────────────────────────────────────────────
            // ACCEPT BUTTON
            // ───────────────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.all(16),
              child: ElevatedButton(
                onPressed: _acceptChecked && !_saving ? _acceptTerms : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  minimumSize: const Size.fromHeight(48),
                ),
                child: _saving
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Text("Accept & Continue"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
