import 'package:flutter/material.dart';

class ImportCsvPage extends StatelessWidget {
  const ImportCsvPage({super.key});

  @override
  Widget build(BuildContext context) {
    return _placeholder(context, "Import Users via CSV");
  }
}
