import 'package:flutter/material.dart';

class ApproveLeavePage extends StatelessWidget {
  const ApproveLeavePage({super.key});

  @override
  Widget build(BuildContext context) {
    return _placeholder(context, "Approve Leave Requests");
  }
}
