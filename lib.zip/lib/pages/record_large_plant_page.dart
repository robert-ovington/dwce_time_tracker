import 'package:flutter/material.dart';

class RecordLargePlantPage extends StatelessWidget {
  const RecordLargePlantPage({super.key});

  @override
  Widget build(BuildContext context) {
    return _placeholder(context, "Record Large Plant");
  }
}
