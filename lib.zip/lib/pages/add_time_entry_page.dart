import 'package:flutter/material.dart';

class AddTimeEntryPage extends StatelessWidget {
  const AddTimeEntryPage({super.key});

  @override
  Widget build(BuildContext context) {
    return _placeholder(context, "Add Time Entry");
  }
}
