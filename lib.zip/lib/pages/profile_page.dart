import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../providers/user_data_provider.dart';
import '../providers/user_setup_provider.dart';
import '../providers/profile_edit_permission_provider.dart';
import '../providers/all_users_provider.dart'; // Admin/Manager only

class ProfilePage extends ConsumerStatefulWidget {
  const ProfilePage({super.key});

  @override
  ConsumerState<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends ConsumerState<ProfilePage> {
  String? _selectedUserId;
  Map<String, dynamic>? _formValues = {};
  bool _saving = false;

  @override
  void initState() {
    super.initState();

    final setup = Supabase.instance.client.auth.currentUser;
    _selectedUserId = setup?.id; // Default to self
  }

@override
Widget build(BuildContext context) {
  // --------------------------------------------
  // STEP 3: Handle route arguments (userId)
  // --------------------------------------------
  final args = ModalRoute.of(context)?.settings.arguments;

  if (args is String && args != _selectedUserId) {
    // The first time we load a user from arguments:
    setState(() {
      _selectedUserId = args;
      _formValues = {}; // clear pending edits
    });
  }

    final supabase = Supabase.instance.client;

    // Data providers
    final userSetup = ref.watch(userSetupProvider).value;
    final userData = ref.watch(userDataProvider).value;

    if (userSetup == null || userData == null) {
      return Scaffold(
        appBar: AppBar(title: const Text("Profile")),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    final loggedInSecurity = int.tryParse(userSetup['security'].toString()) ?? 9;

    // Load all users for Admin/Manager dropdown
    final allUsersAsync = ref.watch(allUsersProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Profile Settings"),
        leading: IconButton(
          icon: const Icon(Icons.home),
          onPressed: () => Navigator.pushReplacementNamed(context, "/home"),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ==================================================================
              // USER SELECTOR FOR ADMIN / MANAGER
              // ==================================================================
              if (loggedInSecurity <= 2) ...[
                Text(
                  "Editing user:",
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 10),

                allUsersAsync.when(
                  data: (users) {
                    return DropdownButtonFormField<String>(
                      value: _selectedUserId,
                      items: users.map((row) {
                        return DropdownMenuItem(
                          value: row['id'],
                          child: Text(row['display_name']),
                        );
                      }).toList(),
                      onChanged: (v) {
                        setState(() {
                          _selectedUserId = v;
                          _formValues = {}; // reset local edits
                        });
                      },
                    );
                  },
                  loading: () =>
                      const CircularProgressIndicator(),
                  error: (err, _) =>
                      Text("Error loading users: $err"),
                ),

                const SizedBox(height: 20),
                Divider(),
                const SizedBox(height: 20),
              ],

              // ==================================================================
              // PHONE NUMBER
              // ==================================================================
              Text("Mobile Number",
                  style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),

              TextFormField(
                initialValue: userData['phone'] ?? '',
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Enter phone number",
                ),
                onChanged: (v) => _formValues!['phone'] = v,
              ),

              const SizedBox(height: 20),
              Divider(),
              const SizedBox(height: 20),

              // ==================================================================
              // HOME LOCATION
              // ==================================================================
              Text("Home Location",
                  style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),

              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      initialValue:
                          userData['home_latitude']?.toString() ?? '',
                      decoration: const InputDecoration(
                          labelText: "Latitude",
                          border: OutlineInputBorder()),
                      onChanged: (v) =>
                          _formValues!['home_latitude'] = double.tryParse(v),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      initialValue:
                          userData['home_longitude']?.toString() ?? '',
                      decoration: const InputDecoration(
                          labelText: "Longitude",
                          border: OutlineInputBorder()),
                      onChanged: (v) =>
                          _formValues!['home_longitude'] = double.tryParse(v),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 12),

              TextFormField(
                initialValue: userData['stock_location'] ?? '',
                decoration: const InputDecoration(
                  labelText: "Stock Location",
                  border: OutlineInputBorder(),
                ),
                onChanged: (v) => _formValues!['stock_location'] = v,
              ),

              const SizedBox(height: 24),
              Divider(),
              const SizedBox(height: 20),

              // ==================================================================
              // WEEKDAY SCHEDULE BLOCKS
              // ==================================================================
              Text("Work Schedule",
                  style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),

              ..._weekdayBlocks(context, userData),

              const SizedBox(height: 20),
              Divider(),
              const SizedBox(height: 20),

              // ==================================================================
              // ADMIN/MANAGER FLAGS
              // ==================================================================
              if (loggedInSecurity <= 2) ...[
                Text("Admin/Manager Settings",
                    style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),

                ..._adminToggle("show_project", userData),
                ..._adminToggle("show_fleet", userData),
                ..._adminToggle("show_allowances", userData),
                ..._adminToggle("show_comments", userData),
                ..._adminToggle("concrete_mix_lorry", userData),
                ..._adminToggle("reinstatement_crew", userData),
                ..._adminToggle("cable_pulling", userData),
                ..._adminToggle("is_mechanic", userData),
                ..._adminToggle("is_public", userData),
                ..._adminToggle("is_active", userData),

                const SizedBox(height: 12),
                Divider(),
              ],

              const SizedBox(height: 20),

              // ==================================================================
              // SAVE BUTTON
              // ==================================================================
              ElevatedButton(
                onPressed: _saving ? null : () => _saveProfile(context),
                child: _saving
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                    : const Text("Save Changes"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ----------------------------------------------------------------
  // WIDGET HELPERS
  // ----------------------------------------------------------------

  List<Widget> _weekdayBlocks(
      BuildContext context, Map<String, dynamic> data) {
    const days = [
      "monday",
      "tuesday",
      "wednesday",
      "thursday",
      "friday"
    ];

    return days.map((day) {
      return _dayScheduleCard(context, day, data);
    }).toList();
  }

  Widget _dayScheduleCard(
      BuildContext context, String day, Map<String, dynamic> data) {
    final title = "${day[0].toUpperCase()}${day.substring(1)}";

    return Card(
      elevation: 1,
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),

            _timeField("$day\_start_time", data),
            const SizedBox(height: 8),
            _timeField("$day\_finish_time", data),
            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                    child: _timeField("$day\_break_1_start", data)),
                const SizedBox(width: 12),
                Expanded(
                    child: _timeField("$day\_break_1_finish", data)),
              ],
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                    child: _timeField("$day\_break_2_start", data)),
                const SizedBox(width: 12),
                Expanded(
                    child: _timeField("$day\_break_2_finish", data)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _timeField(String field, Map<String, dynamic> data) {
    return TextFormField(
      readOnly: true,
      controller: TextEditingController(
        text: data[field]?.toString() ?? "",
      ),
      decoration: InputDecoration(
        labelText: field.replaceAll("_", " ").toUpperCase(),
        border: const OutlineInputBorder(),
      ),
      onTap: () async {
        final initial = _parseTime(data[field]);

        final picked = await showTimePicker(
          context: context,
          initialTime: initial ??
              const TimeOfDay(hour: 8, minute: 0),
        );

        if (picked != null) {
          setState(() {
            _formValues![field] = "${picked.hour}:${picked.minute}:00";
          });
        }
      },
    );
  }

  TimeOfDay? _parseTime(String? value) {
    if (value == null) return null;
    final parts = value.split(":");
    if (parts.length < 2) return null;
    return TimeOfDay(
      hour: int.tryParse(parts[0]) ?? 0,
      minute: int.tryParse(parts[1]) ?? 0,
    );
  }

  List<Widget> _adminToggle(
      String field, Map<String, dynamic> data) {
    return [
      SwitchListTile(
        value: data[field] == true,
        title: Text(field.replaceAll("_", " ").toUpperCase()),
        onChanged: (v) {
          setState(() {
            _formValues![field] = v;
          });
        },
      ),
    ];
  }

  // ----------------------------------------------------------------
  // SAVE LOGIC
  // ----------------------------------------------------------------
  Future<void> _saveProfile(BuildContext context) async {
    if (_formValues!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("No changes to save."),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    setState(() => _saving = true);

    final supabase = Supabase.instance.client;

    try {
      // ---------------------------
      // 1. Update users_data
      // ---------------------------
      final updateMap = Map<String, dynamic>.from(_formValues!);
      updateMap['updated_at'] = DateTime.now().toIso8601String();

      await supabase
          .from('users_data')
          .update(updateMap)
          .eq('user_id', _selectedUserId);

      // ---------------------------
      // 2. Update phone (auth.users)
      // ---------------------------
      if (_formValues!.containsKey('phone')) {
        await supabase.auth.updateUser(
          UserAttributes(
            phone: _formValues!['phone'],
          ),
        );
      }

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Profile updated successfully."),
          backgroundColor: Colors.green,
        ),
      );

      setState(() {
        _formValues = {};
      });

    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Error saving profile: $e"),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }
}
