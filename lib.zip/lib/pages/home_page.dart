import 'dart:io' show Platform;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

import '../providers/user_data_provider.dart';
import '../providers/home_panels_provider.dart';
import '../providers/connectivity_provider.dart';
import '../providers/sync_queue_provider.dart';
import '../widgets/dashboard_tile.dart';

class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userData = ref.watch(userDataProvider).value;
    final panels = ref.watch(homePanelsProvider);
    final isOnline = ref.watch(connectivityProvider);
    final pendingSync = ref.watch(syncQueueCountProvider);

    final forename = userData?['forename'] ?? 'User';

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: SafeArea(
        child: Column(
          children: [
            // ===========================================================
            // HEADER SECTION (DWCE Logo + Greeting)
            // ===========================================================
            Stack(
              children: [
                Column(
                  children: [
                    const SizedBox(height: 20),
                    // Centered DWCE LOGO
                    SizedBox(
                      height: 60,
                      child: Image.asset(
                        'assets/logo/dwce_logo.png',
                        fit: BoxFit.contain,
                      ),
                    ),
                    const SizedBox(height: 12),
                    // Greeting text
                    Text(
                      _greetingText(forename),
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.w600,
                        color: Theme.of(context).colorScheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Divider(
                      height: 1,
                      thickness: 1,
                      color: Colors.white12.withOpacity(0.1),
                    ),
                  ],
                ),

                // ===========================================================
                // CONNECTIVITY & SYNC INDICATORS (top-right)
                // ===========================================================
               Positioned(
                top: 10,
                right: 10,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildConnectivityDot(isOnline),
                    const SizedBox(width: 12),

                    if (pendingSync > 0)
                      _buildPendingSyncBadge(context, pendingSync),

                    const SizedBox(width: 12),

                    // SETTINGS ICON
                    InkWell(
                      onTap: () {
                        Navigator.pushNamed(context, '/profile');
                      },
                      borderRadius: BorderRadius.circular(20),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: Colors.white12,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.settings,
                          size: 22,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            // ===========================================================
            // DASHBOARD PANELS
            // ===========================================================
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final width = constraints.maxWidth;

                    // Determine grid layout based on screen size
                    int columns;
                    if (width > 1200) {
                      columns = 4;
                    } else if (width > 900) {
                      columns = 3;
                    } else if (width > 600) {
                      columns = 2;
                    } else {
                      columns = 1;
                    }

                    if (userSecurity <= 2)
                      DashboardTile(
                        title: "User Management",
                        icon: Icons.group,
                        route: "/user_management",
                      ),

                    return GridView.count(
                      crossAxisCount: columns,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                      childAspectRatio: 2.6,
                      children: panels.map((panel) {
                        return DashboardTile(
                          icon: panel.icon,
                          title: panel.title,
                          subtitle: panel.subtitle,
                          onTap: () {
                            Navigator.pushNamed(
                              context,
                              panel.route,
                            );
                          },
                        );
                      }).toList(),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===============================================================
  // HELPER: Greeting Text
  // ===============================================================
  String _greetingText(String name) {
    final hour = DateTime.now().hour;

    if (hour < 12) return "Good morning, $name";
    if (hour < 17) return "Good afternoon, $name";
    return "Good evening, $name";
  }

  // ===============================================================
  // HELPER: Connectivity Dot
  // ===============================================================
  Widget _buildConnectivityDot(bool isOnline) {
    return Container(
      width: 16,
      height: 16,
      decoration: BoxDecoration(
        color: isOnline ? Colors.green : Colors.red,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 4,
          ),
        ],
      ),
    );
  }

  // ===============================================================
  // HELPER: Pending Sync Badge
  // ===============================================================
  Widget _buildPendingSyncBadge(BuildContext context, int pending) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.orange[700],
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        "$pending pending sync",
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w600,
          fontSize: 12,
        ),
      ),
    );
  }
}
