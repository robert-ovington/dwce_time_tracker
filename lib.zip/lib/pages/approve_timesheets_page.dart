import 'package:flutter/material.dart';

class ApproveTimesheetsPage extends StatelessWidget {
  const ApproveTimesheetsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return _placeholder(context, "Review & Approve Timesheets");
  }
}
