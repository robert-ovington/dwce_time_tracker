import 'package:flutter/material.dart';

class RecordSmallPlantPage extends StatelessWidget {
  const RecordSmallPlantPage({super.key});

  @override
  Widget build(BuildContext context) {
    return _placeholder(context, "Record Small Tools");
  }
}
