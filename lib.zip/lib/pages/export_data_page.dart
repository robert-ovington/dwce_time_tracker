import 'package:flutter/material.dart';

class ExportDataPage extends StatelessWidget {
  const ExportDataPage({super.key});

  @override
  Widget build(BuildContext context) {
    return _placeholder(context, "Export Data");
  }
}
