import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// Providers
import 'providers/system_settings_provider.dart';
import 'providers/user_data_provider.dart';
import 'providers/user_setup_provider.dart';
import 'providers/terms_acceptance_provider.dart';

// Pages
import 'pages/login_page.dart';
import 'pages/auth/terms_page.dart';
import 'pages/home_page.dart';
import 'pages/admin/create_user_page.dart';
import 'pages/help_page.dart';
import 'pages/reset_password_page.dart';

// Placeholder screens from Phase 5 Part 4
import 'pages/timesheet_overview_page.dart';
import 'pages/add_time_entry_page.dart';
import 'pages/leave_request_page.dart';
import 'pages/prestart_checks_page.dart';
import 'pages/record_large_plant_page.dart';
import 'pages/record_small_plant_page.dart';
import 'pages/record_materials_page.dart';
import 'pages/approve_timesheets_page.dart';
import 'pages/approve_leave_page.dart';
import 'pages/import_csv_page.dart';
import 'pages/pending_user_approvals_page.dart';
import 'pages/reports_page.dart';
import 'pages/export_data_page.dart';
import 'pages/system_settings_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: '.env');

  final supabaseUrl = dotenv.env['SUPABASE_URL'];
  final supabaseAnonKey = dotenv.env['SUPABASE_ANON_KEY'];

  if (supabaseUrl == null || supabaseAnonKey == null) {
    throw Exception('SUPABASE_URL and SUPABASE_ANON_KEY must be set in .env');
  }

  await Supabase.initialize(
    url: supabaseUrl,
    anonKey: supabaseAnonKey,
  );

  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends ConsumerStatefulWidget {
  const MyApp({super.key});

  @override
  ConsumerState<MyApp> createState() => _MyAppState();
}

class _MyAppState extends ConsumerState<MyApp> {
  Session? _session;
  late final StreamSubscription<AuthState> _authSub;

  @override
  void initState() {
    super.initState();

    _session = Supabase.instance.client.auth.currentSession;

    _authSub =
        Supabase.instance.client.auth.onAuthStateChange.listen((data) {
      setState(() => _session = data.session);
    });
  }

  @override
  void dispose() {
    _authSub.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DWCE Time Tracker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),

      // -----------------------------------------------
      // Routes
      // -----------------------------------------------
      routes: {
        '/login': (_) => const LoginPage(),
        '/home': (_) => const HomePage(),

        '/timesheet_overview': (_) => const TimesheetOverviewPage(),
        '/add_time_entry': (_) => const AddTimeEntryPage(),
        '/leave_request': (_) => const LeaveRequestPage(),
        '/prestart_checks': (_) => const PrestartChecksPage(),
        '/record_large_plant': (_) => const RecordLargePlantPage(),
        '/record_small_plant': (_) => const RecordSmallPlantPage(),
        '/record_materials': (_) => const RecordMaterialsPage(),
        '/approve_timesheets': (_) => const ApproveTimesheetsPage(),
        '/approve_leave': (_) => const ApproveLeavePage(),
        '/profile': (_) => const ProfilePage(),
        '/create_user': (_) => const CreateUserPage(),
        '/import_csv': (_) => const ImportCsvPage(),
        '/pending_user_approvals': (_) => const PendingUserApprovalsPage(),
        '/reports': (_) => const ReportsPage(),
        '/export_data': (_) => const ExportDataPage(),
        '/system_settings': (_) => const SystemSettingsPage(),
        '/user_management': (_) => const UserManagementPage(),
      },

      // -----------------------------------------------
      // Root Page Logic
      // -----------------------------------------------
      home: _buildRoot(),
    );
  }

  /// Decides what the user should see on app launch
  Widget _buildRoot() {
    // User not logged in → show login
    if (_session == null) {
      return const LoginPage();
    }

    // Check Terms & Conditions acceptance
    final needsTerms = ref.watch(needsTermsAcceptanceProvider);

    if (needsTerms) {
      return const TermsPage();
    }

    // Logged in, terms accepted → Home Dashboard
    return const HomePage();
  }
}
