import 'package:flutter/material.dart';

class DWCEColors {
  static const blue = Color(0xFF0096FF);
  static const blueDark = Color(0xFF0076CC);
  static const greyBackground = Color(0xFFF2F4F8);
}
