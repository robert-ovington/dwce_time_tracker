import 'dart:convert';
import 'package:supabase_flutter/supabase_flutter.dart';

class GoogleTravelService {
  final SupabaseClient _supabase = Supabase.instance.client;

  /// Fetch or cache travel time between home and project
  Future<GoogleTravelResult?> getTravelData({
    required double homeLat,
    required double homeLng,
    required double projectLat,
    required double projectLng,
  }) async {
    try {
      final response = await _supabase.functions.invoke(
        'get_travel_time',
        body: {
          'home_lat': homeLat,
          'home_lng': homeLng,
          'project_lat': projectLat,
          'project_lng': projectLng,
        },
      );

      if (response.data == null) {
        return null;
      }

      final data = response.data as Map<String, dynamic>;

      return GoogleTravelResult(
        fromCache: data['from_cache'] ?? false,
        travelMinutes: data['travel_time_minutes'],
        travelText: data['travel_time_formatted'],
        distanceKm: (data['distance_kilometers'] as num).toDouble(),
        distanceText: data['distance_text'],
      );
    } catch (e) {
      print("Google Travel Error: $e");
      return null;
    }
  }
}

class GoogleTravelResult {
  final bool fromCache;
  final int travelMinutes;
  final String travelText;
  final double distanceKm;
  final String distanceText;

  GoogleTravelResult({
    required this.fromCache,
    required this.travelMinutes,
    required this.travelText,
    required this.distanceKm,
    required this.distanceText,
  });
}
