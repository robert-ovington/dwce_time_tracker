import 'package:supabase_flutter/supabase_flutter.dart';

class UserAdminService {
  final supabase = Supabase.instance.client;

  Future<Map<String, dynamic>> createUser({
    required String forename,
    required String surname,
    required String initials,
    required String email,
    required String role,
    required int security,
    String? phone,
    String? password,
    required bool sendInvite,
  }) async {
    final response = await supabase.functions.invoke(
      'create_user_admin',
      body: {
        'forename': forename,
        'surname': surname,
        'initials': initials,
        'email': email,
        'role': role,
        'security': security,
        'phone': phone,
        'password': password,
        'sendInvite': sendInvite,
      },
    );

    if (response.error != null) {
      throw Exception(response.error!.message);
    }

    final data = response.data;
    if (data == null) throw Exception('Unexpected null response');

    if (data['error'] != null) {
      throw Exception(data['error']);
    }

    return data;
  }
}
