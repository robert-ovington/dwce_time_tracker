import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'system_settings_provider.dart';
import 'user_data_provider.dart';

final needsTermsAcceptanceProvider = Provider<bool>((ref) {
  final systemSettings = ref.watch(systemSettingsProvider).value ?? {};
  final userData = ref.watch(userDataProvider).value;

  if (userData == null) return false; // not loaded yet

  final appTermsDate = systemSettings['terms_version_date'];
  final userAcceptedDate = userData['terms_accepted_date'];

  // No system terms configured → no need to block users
  if (appTermsDate == null) return false;

  // If user never accepted
  if (userAcceptedDate == null) return true;

  // If system version is newer than what user accepted
  return DateTime.parse(userAcceptedDate)
      .isBefore(DateTime.parse(appTermsDate));
});
