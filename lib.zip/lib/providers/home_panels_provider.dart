import 'dart:io' show Platform;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/user_setup_provider.dart';

/// ===============================================================
/// A model to represent each dashboard tile
/// ===============================================================
class DashboardPanel {
  final String title;
  final String? subtitle;
  final IconData icon;
  final String route;

  DashboardPanel({
    required this.title,
    required this.icon,
    required this.route,
    this.subtitle,
  });
}

/// ===============================================================
/// Home Panels Provider
/// Builds the list of dashboard tiles based on role + security
/// ===============================================================
final homePanelsProvider = Provider<List<DashboardPanel>>((ref) {
  final userSetup = ref.watch(userSetupProvider).value;
  if (userSetup == null) return [];

  final role = (userSetup['role'] ?? '').toString();
  final security = int.tryParse(userSetup['security']?.toString() ?? '9') ?? 9;

  final isMobile = !kIsWeb && (Platform.isAndroid || Platform.isIOS);
  final isWeb = kIsWeb;

  // List of allowed panels
  final List<DashboardPanel> panels = [];

  // ===============================================================
  // UNIVERSAL PANELS (Visible to nearly all roles)
  // ===============================================================
  panels.add(
    DashboardPanel(
      title: "Timesheet Overview",
      subtitle: "Weekly summary & history",
      icon: Icons.calendar_month,
      route: "/timesheet_overview",
    ),
  );

  panels.add(
    DashboardPanel(
      title: "Add Time Entry",
      subtitle: "Record your work",
      icon: Icons.timer,
      route: "/add_time_entry",
    ),
  );

  panels.add(
    DashboardPanel(
      title: "Submit Leave Request",
      subtitle: "Holiday / sick leave",
      icon: Icons.beach_access,
      route: "/leave_request",
    ),
  );

  panels.add(
    DashboardPanel(
      title: "Large Plant Pre-Start",
      subtitle: "Daily safety checks",
      icon: Icons.construction,
      route: "/prestart_checks",
    ),
  );

  // ===============================================================
  // PLANT / MATERIAL PANELS
  // Visible for Supervisor, PICW, Driver, Fitter, Mechanic
  // ===============================================================
  if (security <= 6) {
    panels.add(
      DashboardPanel(
        title: "Record Large Plant",
        subtitle: "Track plant on a project",
        icon: Icons.local_shipping,
        route: "/record_large_plant",
      ),
    );

    panels.add(
      DashboardPanel(
        title: "Record Small Tools",
        subtitle: "Small plant on site",
        icon: Icons.home_repair_service,
        route: "/record_small_plant",
      ),
    );

    panels.add(
      DashboardPanel(
        title: "Record Materials",
        subtitle: "Materials used on site",
        icon: Icons.inventory,
        route: "/record_materials",
      ),
    );
  }

  // ===============================================================
  // SUPERVISOR & MANAGER APPROVAL PANELS
  // security <= 3 (Manager=2, Supervisor=3)
  // ===============================================================
  if (security <= 3) {
    panels.add(
      DashboardPanel(
        title: "Review Timesheets",
        subtitle: "Approve or adjust entries",
        icon: Icons.fact_check,
        route: "/approve_timesheets",
      ),
    );

    panels.add(
      DashboardPanel(
        title: "Approve Leave Requests",
        subtitle: "Pending leave approval",
        icon: Icons.approval,
        route: "/approve_leave",
      ),
    );
  }

  // ===============================================================
  // CREATE USER PANEL
  // Admin + Manager + Supervisor + PICW
  // ===============================================================
  final canCreateUsersWeb = (security == 1 || security == 2);
  final canCreateUsersMobile = (security <= 4);

  if ((isWeb && canCreateUsersWeb) || (isMobile && canCreateUsersMobile)) {
    panels.add(
      DashboardPanel(
        title: "Create User",
        subtitle: "Add new team member",
        icon: Icons.person_add,
        route: "/create_user",
      ),
    );
  }

  // ===============================================================
  // ADMIN-ONLY PANELS (SECURITY LEVEL 1)
  // ===============================================================
  if (security == 1) {
    if (isWeb) {
      panels.add(
        DashboardPanel(
          title: "Import CSV Users",
          subtitle: "Bulk user creation",
          icon: Icons.upload_file,
          route: "/import_csv",
        ),
      );

      panels.add(
        DashboardPanel(
          title: "Pending User Approvals",
          subtitle: "Approve newly created users",
          icon: Icons.how_to_reg,
          route: "/pending_user_approvals",
        ),
      );

      panels.add(
        DashboardPanel(
          title: "Reports",
          subtitle: "Generate timesheet reports",
          icon: Icons.insert_chart,
          route: "/reports",
        ),
      );

      panels.add(
        DashboardPanel(
          title: "Export Data",
          subtitle: "Excel / Access export",
          icon: Icons.download,
          route: "/export_data",
        ),
      );

      panels.add(
        DashboardPanel(
          title: "System Settings",
          subtitle: "We
