import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final systemSettingsProvider =
    FutureProvider<Map<String, dynamic>?>((ref) async {
  final supabase = Supabase.instance.client;

  final result = await supabase
      .from('system_settings')
      .select()
      .limit(1)
      .maybeSingle();

  return result;
});

final weekStartProvider = Provider<String>((ref) {
  final settings = ref.watch(systemSettingsProvider).value;
  return settings?['week_start'] ?? 'Monday';
});

final termsProvider = Provider<String>((ref) {
  final settings = ref.watch(systemSettingsProvider).value;
  return settings?['terms_and_conditions'] ?? '';
});
