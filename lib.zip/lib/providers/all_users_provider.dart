import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final allUsersProvider = FutureProvider<List<Map<String, dynamic>>>((ref) async {
  final supabase = Supabase.instance.client;

  final data = await supabase
      .from('users_setup')
      .select('user_id, display_name')
      .order('display_name');

  // Convert to expected format
  return data.map((row) {
    return {
      'id': row['user_id'],
      'display_name': row['display_name'],
    };
  }).toList();
});
