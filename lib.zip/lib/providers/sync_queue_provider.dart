import 'package:flutter_riverpod/flutter_riverpod.dart';

/// A simple in-memory queue for unsynced operations.
/// Will later be replaced with Drift or Hive for persistence.
final syncQueueProvider =
    StateNotifierProvider<SyncQueueNotifier, List<String>>((ref) {
  return SyncQueueNotifier();
});

class SyncQueueNotifier extends StateNotifier<List<String>> {
  SyncQueueNotifier() : super([]);

  void add(String op) {
    state = [...state, op];
  }

  void remove(String op) {
    state = state.where((e) => e != op).toList();
  }

  void clear() {
    state = [];
  }
}

/// Number of pending items → used in HomePage badge
final syncQueueCountProvider = Provider<int>((ref) {
  return ref.watch(syncQueueProvider).length;
});
