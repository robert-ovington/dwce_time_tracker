import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final concreteMixProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async {
  final supabase = Supabase.instance.client;

  final result = await supabase
      .from('concrete_mix')
      .select()
      .eq('is_active', true)
      .order('product_no', ascending: true);

  return result;
});
