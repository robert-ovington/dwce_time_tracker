import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/user_admin_service.dart';

final userAdminServiceProvider = Provider((ref) => UserAdminService());

final createUserProvider =
    StateNotifierProvider<CreateUserController, AsyncValue<dynamic>>(
  (ref) => CreateUserController(ref.read),
);

class CreateUserController extends StateNotifier<AsyncValue<dynamic>> {
  final Reader read;

  CreateUserController(this.read) : super(const AsyncValue.data(null));

  Future<void> createUser({
    required String forename,
    required String surname,
    required String initials,
    required String email,
    required String role,
    required int security,
    String? phone,
    String? password,
    required bool sendInvite,
  }) async {
    try {
      state = const AsyncValue.loading();

      final response = await read(userAdminServiceProvider).createUser(
        forename: forename,
        surname: surname,
        initials: initials,
        email: email,
        role: role,
        security: security,
        phone: phone,
        password: password,
        sendInvite: sendInvite,
      );

      state = AsyncValue.data(response);
    } catch (err, st) {
      state = AsyncValue.error(err.toString(), st);
    }
  }
}
