import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'user_setup_provider.dart';

final profileEditPermissionProvider =
    Provider.family<bool, Map<String, dynamic>>((ref, targetUser) {
  final current = ref.watch(userSetupProvider).value;

  if (current == null) return false;

  final currentSec = int.parse(current['security'].toString());
  final targetSec = int.parse(targetUser['security'].toString());

  // Admin can edit anyone
  if (currentSec == 1) return true;

  // Manager can edit 2-9, but NOT 1
  if (currentSec == 2 && targetSec >= 2) return true;

  // Users 3-9 can edit ONLY themselves
  return current['user_id'] == targetUser['user_id'];
});
