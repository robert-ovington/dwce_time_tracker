import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../utils/csv_parser.dart';

class CsvImportState {
  final List<CsvRow> rows;
  final List<String> errors;
  final bool readyToImport;

  CsvImportState({
    required this.rows,
    required this.errors,
    required this.readyToImport,
  });
}

final csvImportProvider =
    StateNotifierProvider<CsvImportController, CsvImportState>(
  (ref) => CsvImportController(),
);

class CsvImportController extends StateNotifier<CsvImportState> {
  CsvImportController()
      : super(CsvImportState(rows: [], errors: [], readyToImport: false));

  void loadCsv(String text) {
    final rows = parseCsv(text);

    final errors = <String>[];

    for (int i = 0; i < rows.length; i++) {
      final row = rows[i].fields;

      if ((row['forename'] ?? '').isEmpty) {
        errors.add("Row ${i + 2}: Missing forename");
      }
      if ((row['surname'] ?? '').isEmpty) {
        errors.add("Row ${i + 2}: Missing surname");
      }
      if ((row['initials'] ?? '').isEmpty) {
        errors.add("Row ${i + 2}: Missing initials");
      }
      if (!(row['email'] ?? '').contains('@')) {
        errors.add("Row ${i + 2}: Invalid email");
      }
      if ((row['role'] ?? '').isEmpty) {
        errors.add("Row ${i + 2}: Missing role");
      }
      final sec = int.tryParse(row['security'] ?? '');
      if (sec == null || sec < 1 || sec > 9) {
        errors.add("Row ${i + 2}: Invalid security level");
      }
    }

    state = CsvImportState(
      rows: rows,
      errors: errors,
      readyToImport: errors.isEmpty,
    );
  }

  void updateRow(int index, CsvRow updated) {
    final updatedList = [...state.rows];
    updatedList[index] = updated;
    state = CsvImportState(
      rows: updatedList,
      errors: state.errors,
      readyToImport: state.readyToImport,
    );
  }
}
