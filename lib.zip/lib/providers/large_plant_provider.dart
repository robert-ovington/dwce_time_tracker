import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final activeLargePlantProvider =
    FutureProvider<List<LargePlantModel>>((ref) async {
  final supabase = Supabase.instance.client;

  final result = await supabase
      .from('large_plant')
      .select()
      .eq('is_active', true)
      .order('large_plant_no');

  return (result as List<dynamic>)
      .map((row) => LargePlantModel.fromMap(row))
      .toList();
});

class LargePlantModel {
  final String id;
  final String largePlantNo;
  final String largePlantDescription;

  LargePlantModel({
    required this.id,
    required this.largePlantNo,
    required this.largePlantDescription,
  });

  factory LargePlantModel.fromMap(Map<String, dynamic> data) {
    return LargePlantModel(
      id: data['id'],
      largePlantNo: data['large_plant_no'] ?? '',
      largePlantDescription: data['large_plant_description'] ?? '',
    );
  }
}
