import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final activeProjectListProvider =
    FutureProvider<List<ProjectModel>>((ref) async {
  final supabase = Supabase.instance.client;

  final data = await supabase
      .from('projects')
      .select()
      .eq('is_active', true)
      .order('project_number');

  return (data as List<dynamic>)
      .map((row) => ProjectModel.fromMap(row))
      .toList();
});

class ProjectModel {
  final String id;
  final String? projectNumber;
  final String projectName;
  final double? latitude;
  final double? longitude;

  ProjectModel({
    required this.id,
    this.projectNumber,
    required this.projectName,
    this.latitude,
    this.longitude,
  });

  factory ProjectModel.fromMap(Map<String, dynamic> map) {
    return ProjectModel(
      id: map['id'],
      projectNumber: map['project_number'],
      projectName: map['project_name'] ?? 'Unnamed Project',
      latitude: map['latitude']?.toDouble(),
      longitude: map['longitude']?.toDouble(),
    );
  }
}
