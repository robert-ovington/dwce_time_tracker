import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Loads the current user's record from public.users_data
final userDataProvider = FutureProvider<Map<String, dynamic>?>((ref) async {
  final supabase = Supabase.instance.client;
  final user = supabase.auth.currentUser;

  if (user == null) return null;

  final response = await supabase
      .from('users_data')
      .select()
      .eq('user_id', user.id)
      .maybeSingle();

  return response;
});

/// Determines whether the Fleet Section should be shown.
/// This is based on flags stored in public.users_data
final showFleetSectionProvider = Provider<bool>((ref) {
  final userData = ref.watch(userDataProvider).maybeWhen(
        data: (data) => data,
        orElse: () => null,
      );

  if (userData == null) return false;

  return (userData['concrete_mix_lorry'] == true) ||
      (userData['reinstatement_crew'] == true) ||
      (userData['is_mechanic'] == true) ||
      (userData['show_fleet'] == true);
});
